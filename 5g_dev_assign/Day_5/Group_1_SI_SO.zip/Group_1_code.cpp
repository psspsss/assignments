/**
 * ═══════════════════════════════════════════════════════════════════════════
 * 5G NR RLC SEGMENTATION - SI & SO FIELD DEMONSTRATION
 * ═══════════════════════════════════════════════════════════════════════════
 *
 * Standard Compliance: 3GPP TS 38.322 v19.0.0 (Radio Link Control Protocol)
 *
 * This implementation demonstrates RLC SDU segmentation with:
 *   - Segmentation Information (SI) field (2 bits)
 *   - Segment Offset (SO) field (16 bits)
 *   - Complete segmentation and reassembly procedures
 *
 * Focus Areas:
 *   1. SI Field (TS 38.322 Section 6.2.3.4): Indicates segment type
 *   2. SO Field (TS 38.322 Section 6.2.3.5): Indicates byte position
 *   3. UMD/AMD PDU Construction (Section 6.2.2.3/6.2.2.4)
 *   4. Segmentation Procedures (Section 4.2.1.2/4.2.1.3)
 *
 * Author: 5G RLC Protocol Implementation
 * Date: February 2026
 * ═══════════════════════════════════════════════════════════════════════════
 */

#include <cstdint>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: SEGMENTATION INFORMATION (SI) FIELD DEFINITIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Segmentation Information (SI) field values
 *
 * As per 3GPP TS 38.322 Section 6.2.3.4, Table 6.2.3.4-1
 * Length: 2 bits
 *
 * The SI field indicates whether an RLC PDU contains:
 * - A complete RLC SDU (no segmentation)
 * - The first segment of an RLC SDU
 * - The last segment of an RLC SDU
 * - A middle segment of an RLC SDU
 */
enum class SI_Field : uint8_t {
  COMPLETE_SDU = 0x00, // 00b - Data field contains all bytes of an RLC SDU
  FIRST_SEGMENT =
      0x01, // 01b - Data field contains the first segment of an RLC SDU
  LAST_SEGMENT =
      0x02, // 10b - Data field contains the last segment of an RLC SDU
  MIDDLE_SEGMENT =
      0x03 // 11b - Data field contains neither first nor last segment
};

/**
 * @brief Convert SI field value to string representation
 */
const char *si_field_to_string(SI_Field si) {
  switch (si) {
  case SI_Field::COMPLETE_SDU:
    return "COMPLETE SDU (00b)";
  case SI_Field::FIRST_SEGMENT:
    return "FIRST SEGMENT (01b)";
  case SI_Field::LAST_SEGMENT:
    return "LAST SEGMENT (10b)";
  case SI_Field::MIDDLE_SEGMENT:
    return "MIDDLE SEGMENT (11b)";
  default:
    return "UNKNOWN";
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2: RLC PDU STRUCTURES (3GPP TS 38.322 Section 6.2)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief RLC UMD PDU Header Structure (12-bit SN with SO)
 *
 * As per 3GPP TS 38.322 Section 6.2.2.3, Figure 6.2.2.3-5
 *
 * Byte 0:  SI (2 bits) | R (2 bits) | SN[11:8] (4 bits)
 * Byte 1:  SN[7:0] (8 bits)
 * Byte 2:  SO[15:8] (8 bits)  [Only if segment, not first]
 * Byte 3:  SO[7:0] (8 bits)   [Only if segment, not first]
 */
struct UMD_PDU_Header {
  SI_Field si; // Segmentation Information (2 bits)
  uint16_t sn; // Sequence Number (12 bits for UM)
  uint16_t so; // Segment Offset (16 bits) - present only for segments
  bool has_so; // Indicates if SO field is present

  UMD_PDU_Header() : si(SI_Field::COMPLETE_SDU), sn(0), so(0), has_so(false) {}

  /**
   * @brief Get header size in bytes
   */
  size_t get_header_size() const {
    if (si == SI_Field::COMPLETE_SDU) {
      return 1; // Only SI field (with padding)
    } else if (si == SI_Field::FIRST_SEGMENT) {
      return 2; // SI + SN (no SO for first segment)
    } else {
      return 4; // SI + SN + SO (for middle/last segments)
    }
  }

  /**
   * @brief Serialize header to byte array
   */
  void serialize(uint8_t *buffer) const {
    if (si == SI_Field::COMPLETE_SDU) {
      // TS 38.322 Figure 6.2.2.3-1: UMD PDU containing complete SDU
      buffer[0] = (static_cast<uint8_t>(si) << 6); // SI in bits 7-6
      // Bits 5-0 are reserved (R fields)
    } else if (si == SI_Field::FIRST_SEGMENT) {
      // TS 38.322 Figure 6.2.2.3-3: UMD PDU with 12-bit SN (No SO)
      buffer[0] = (static_cast<uint8_t>(si) << 6) | // SI in bits 7-6
                  ((sn >> 8) & 0x0F);               // SN[11:8] in bits 3-0
      buffer[1] = sn & 0xFF;                        // SN[7:0]
    } else {
      // TS 38.322 Figure 6.2.2.3-5: UMD PDU with 12-bit SN and SO
      buffer[0] = (static_cast<uint8_t>(si) << 6) | // SI in bits 7-6
                  ((sn >> 8) & 0x0F);               // SN[11:8] in bits 3-0
      buffer[1] = sn & 0xFF;                        // SN[7:0]
      buffer[2] = (so >> 8) & 0xFF;                 // SO[15:8]
      buffer[3] = so & 0xFF;                        // SO[7:0]
    }
  }

  /**
   * @brief Deserialize header from byte array
   */
  void deserialize(const uint8_t *buffer) {
    // Extract SI field (bits 7-6 of first byte)
    si = static_cast<SI_Field>((buffer[0] >> 6) & 0x03);

    if (si == SI_Field::COMPLETE_SDU) {
      sn = 0;
      so = 0;
      has_so = false;
    } else if (si == SI_Field::FIRST_SEGMENT) {
      // Extract 12-bit SN
      sn = ((buffer[0] & 0x0F) << 8) | buffer[1];
      so = 0;
      has_so = false;
    } else {
      // Extract 12-bit SN and 16-bit SO
      sn = ((buffer[0] & 0x0F) << 8) | buffer[1];
      so = (buffer[2] << 8) | buffer[3];
      has_so = true;
    }
  }
};

/**
 * @brief RLC AMD PDU Header Structure (12-bit SN with SO)
 *
 * As per 3GPP TS 38.322 Section 6.2.2.4, Figure 6.2.2.4-3
 *
 * Byte 0:  D/C (1 bit) | P (1 bit) | SI (2 bits) | SN[11:8] (4 bits)
 * Byte 1:  SN[7:0] (8 bits)
 * Byte 2:  SO[15:8] (8 bits)  [Only if segment, not first]
 * Byte 3:  SO[7:0] (8 bits)   [Only if segment, not first]
 */
struct AMD_PDU_Header {
  uint8_t dc;  // Data/Control field (1 bit) - always 1 for data
  uint8_t p;   // Polling bit (1 bit)
  SI_Field si; // Segmentation Information (2 bits)
  uint16_t sn; // Sequence Number (12 bits for AM)
  uint16_t so; // Segment Offset (16 bits)
  bool has_so; // Indicates if SO field is present

  AMD_PDU_Header()
      : dc(1), p(0), si(SI_Field::COMPLETE_SDU), sn(0), so(0), has_so(false) {}

  /**
   * @brief Get header size in bytes
   */
  size_t get_header_size() const {
    if (si == SI_Field::COMPLETE_SDU || si == SI_Field::FIRST_SEGMENT) {
      return 2; // D/C + P + SI + SN (no SO)
    } else {
      return 4; // D/C + P + SI + SN + SO
    }
  }

  /**
   * @brief Serialize header to byte array
   */
  void serialize(uint8_t *buffer) const {
    // TS 38.322 Section 6.2.2.4
    buffer[0] = (dc << 7) |                       // D/C bit
                (p << 6) |                        // P bit
                (static_cast<uint8_t>(si) << 4) | // SI field
                ((sn >> 8) & 0x0F);               // SN[11:8]
    buffer[1] = sn & 0xFF;                        // SN[7:0]

    if (si == SI_Field::MIDDLE_SEGMENT || si == SI_Field::LAST_SEGMENT) {
      buffer[2] = (so >> 8) & 0xFF; // SO[15:8]
      buffer[3] = so & 0xFF;        // SO[7:0]
    }
  }

  /**
   * @brief Deserialize header from byte array
   */
  void deserialize(const uint8_t *buffer) {
    dc = (buffer[0] >> 7) & 0x01;
    p = (buffer[0] >> 6) & 0x01;
    si = static_cast<SI_Field>((buffer[0] >> 4) & 0x03);
    sn = ((buffer[0] & 0x0F) << 8) | buffer[1];

    if (si == SI_Field::MIDDLE_SEGMENT || si == SI_Field::LAST_SEGMENT) {
      so = (buffer[2] << 8) | buffer[3];
      has_so = true;
    } else {
      so = 0;
      has_so = false;
    }
  }
};

/**
 * @brief RLC SDU Segment Structure
 */
struct RLC_Segment {
  SI_Field si;              // Segment type
  uint16_t sn;              // Sequence number
  uint16_t so;              // Segment offset (byte position in original SDU)
  uint8_t *data;            // Segment data
  size_t data_length;       // Length of segment data
  size_t original_sdu_size; // Total size of original SDU

  RLC_Segment()
      : si(SI_Field::COMPLETE_SDU), sn(0), so(0), data(nullptr), data_length(0),
        original_sdu_size(0) {}

  ~RLC_Segment() {
    if (data) {
      delete[] data;
    }
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3: UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Print hex dump of byte array
 */
void print_hex(const std::string &label, const uint8_t *data, size_t length) {
  std::cout << label << " (" << length << " bytes):\n  0x";
  for (size_t i = 0; i < length; i++) {
    std::cout << std::hex << std::setw(2) << std::setfill('0')
              << static_cast<int>(data[i]);
    if ((i + 1) % 32 == 0 && i + 1 < length)
      std::cout << "\n  0x";
  }
  std::cout << std::dec << "\n";
}

/**
 * @brief Print binary representation of byte
 */
void print_binary(const std::string &label, uint8_t byte) {
  std::cout << label << ": ";
  for (int i = 7; i >= 0; i--) {
    std::cout << ((byte >> i) & 1);
  }
  std::cout << "b\n";
}

/**
 * @brief Convert string to bytes
 */
void string_to_bytes(const std::string &str, uint8_t *output) {
  for (size_t i = 0; i < str.length(); i++) {
    output[i] = static_cast<uint8_t>(str[i]);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4: RLC SEGMENTATION ENGINE
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Segment an RLC SDU into multiple segments
 *
 * As per 3GPP TS 38.322 Section 4.2.1.2.2 and 4.2.1.3.2
 *
 * @param sdu           Original RLC SDU data
 * @param sdu_length    Length of original SDU
 * @param sn            Sequence number to assign
 * @param max_pdu_size  Maximum PDU size (including header)
 * @param segments      [out] Vector of created segments
 * @param is_am         True for AM mode, False for UM mode
 */
void segment_rlc_sdu(const uint8_t *sdu, size_t sdu_length, uint16_t sn,
                     size_t max_pdu_size, std::vector<RLC_Segment *> &segments,
                     bool is_am = false) {

  std::cout << "\n";
  std::cout
      << "╔═══════════════════════════════════════════════════════════════╗\n";
  std::cout
      << "║  RLC SDU SEGMENTATION PROCESS                                 ║\n";
  std::cout
      << "╚═══════════════════════════════════════════════════════════════╝\n";
  std::cout << "3GPP Reference: TS 38.322 Section 4.2.1.2.2/4.2.1.3.2\n\n";

  std::cout << "[SEGMENTATION INPUT]\n";
  std::cout << "  → Original SDU Length: " << sdu_length << " bytes\n";
  std::cout << "  → Sequence Number (SN): " << sn << "\n";
  std::cout << "  → Max PDU Size: " << max_pdu_size << " bytes\n";
  std::cout << "  → Mode: " << (is_am ? "AM" : "UM") << "\n\n";

  // Calculate header sizes for different segment types
  size_t first_segment_header_size = is_am ? 2 : 2; // No SO field
  size_t other_segment_header_size = is_am ? 4 : 4; // With SO field

  // Calculate available payload sizes
  size_t first_segment_payload = max_pdu_size - first_segment_header_size;
  size_t other_segment_payload = max_pdu_size - other_segment_header_size;

  std::cout << "[HEADER SIZE CALCULATION]\n";
  std::cout << "  → First Segment Header: " << first_segment_header_size
            << " bytes (SI + SN, no SO)\n";
  std::cout << "  → Other Segment Header: " << other_segment_header_size
            << " bytes (SI + SN + SO)\n";
  std::cout << "  → First Segment Payload: " << first_segment_payload
            << " bytes\n";
  std::cout << "  → Other Segment Payload: " << other_segment_payload
            << " bytes\n\n";

  // Check if segmentation is needed
  if (sdu_length + first_segment_header_size <= max_pdu_size) {
    std::cout << "[SEGMENTATION DECISION] No segmentation needed\n";
    std::cout << "  → SDU fits in single PDU\n\n";

    RLC_Segment *segment = new RLC_Segment();
    segment->si = SI_Field::COMPLETE_SDU;
    segment->sn = sn;
    segment->so = 0;
    segment->data_length = sdu_length;
    segment->original_sdu_size = sdu_length;
    segment->data = new uint8_t[sdu_length];
    memcpy(segment->data, sdu, sdu_length);
    segments.push_back(segment);
    return;
  }

  std::cout << "[SEGMENTATION DECISION] Segmentation required\n";
  std::cout << "  → SDU will be split into multiple segments\n\n";

  // Calculate number of segments needed
  size_t remaining = sdu_length;
  size_t offset = 0;
  int segment_count = 0;

  // First segment
  size_t first_chunk = std::min(first_segment_payload, remaining);
  remaining -= first_chunk;
  segment_count++;

  // Calculate remaining segments
  while (remaining > 0) {
    size_t chunk = std::min(other_segment_payload, remaining);
    remaining -= chunk;
    segment_count++;
  }

  std::cout << "[SEGMENT CALCULATION]\n";
  std::cout << "  → Total segments needed: " << segment_count << "\n\n";

  // Create segments
  remaining = sdu_length;
  offset = 0;

  for (int i = 0; i < segment_count; i++) {
    RLC_Segment *segment = new RLC_Segment();
    segment->sn = sn;
    segment->original_sdu_size = sdu_length;

    // Determine SI field and data length
    if (i == 0) {
      // First segment
      segment->si = SI_Field::FIRST_SEGMENT;
      segment->so = 0; // SO not included in first segment
      segment->data_length = std::min(first_segment_payload, remaining);
    } else if (i == segment_count - 1) {
      // Last segment
      segment->si = SI_Field::LAST_SEGMENT;
      segment->so = offset;
      segment->data_length = remaining;
    } else {
      // Middle segment
      segment->si = SI_Field::MIDDLE_SEGMENT;
      segment->so = offset;
      segment->data_length = std::min(other_segment_payload, remaining);
    }

    // Copy data
    segment->data = new uint8_t[segment->data_length];
    memcpy(segment->data, sdu + offset, segment->data_length);

    std::cout
        << "─────────────────────────────────────────────────────────────\n";
    std::cout << "[SEGMENT #" << (i + 1) << "]\n";
    std::cout << "  → SI Field: " << si_field_to_string(segment->si) << "\n";
    std::cout << "  → SN: " << segment->sn << "\n";
    std::cout << "  → SO: " << segment->so << " bytes";
    if (segment->si == SI_Field::FIRST_SEGMENT) {
      std::cout << " (not included in header)";
    }
    std::cout << "\n";
    std::cout << "  → Data Length: " << segment->data_length << " bytes\n";
    std::cout << "  → Byte Range: [" << offset << " - "
              << (offset + segment->data_length - 1) << "]\n";
    std::cout << "  → Header Size: "
              << (segment->si == SI_Field::FIRST_SEGMENT
                      ? first_segment_header_size
                      : other_segment_header_size)
              << " bytes\n";
    std::cout << "  → Total PDU Size: "
              << (segment->data_length + (segment->si == SI_Field::FIRST_SEGMENT
                                              ? first_segment_header_size
                                              : other_segment_header_size))
              << " bytes\n";

    segments.push_back(segment);
    offset += segment->data_length;
    remaining -= segment->data_length;
  }

  std::cout
      << "─────────────────────────────────────────────────────────────\n";
  std::cout << "\n✓ SEGMENTATION COMPLETE\n";
  std::cout << "  → Created " << segment_count
            << " segments from original SDU\n";
  std::cout << "  → Total bytes segmented: " << sdu_length << "\n\n";
}

/**
 * @brief Reassemble RLC SDU from segments
 *
 * As per 3GPP TS 38.322 Section 5.2.2.2.3 and 5.2.3.2.3
 *
 * @param segments      Vector of received segments
 * @param reassembled   [out] Reassembled SDU buffer
 * @return              Length of reassembled SDU, or 0 on failure
 */
size_t reassemble_rlc_sdu(const std::vector<RLC_Segment *> &segments,
                          uint8_t *reassembled) {

  std::cout << "\n";
  std::cout
      << "╔═══════════════════════════════════════════════════════════════╗\n";
  std::cout
      << "║  RLC SDU REASSEMBLY PROCESS                                   ║\n";
  std::cout
      << "╚═══════════════════════════════════════════════════════════════╝\n";
  std::cout << "3GPP Reference: TS 38.322 Section 5.2.2.2.3/5.2.3.2.3\n\n";

  if (segments.empty()) {
    std::cout << "✗ ERROR: No segments to reassemble\n";
    return 0;
  }

  std::cout << "[REASSEMBLY INPUT]\n";
  std::cout << "  → Number of segments: " << segments.size() << "\n";
  std::cout << "  → Sequence Number: " << segments[0]->sn << "\n\n";

  // Check if we have a complete SDU (no segmentation)
  if (segments.size() == 1 && segments[0]->si == SI_Field::COMPLETE_SDU) {
    std::cout << "[REASSEMBLY TYPE] Complete SDU (no segmentation)\n";
    memcpy(reassembled, segments[0]->data, segments[0]->data_length);
    std::cout << "  → SDU Length: " << segments[0]->data_length << " bytes\n";
    std::cout << "\n✓ REASSEMBLY COMPLETE\n\n";
    return segments[0]->data_length;
  }

  std::cout << "[REASSEMBLY TYPE] Segmented SDU reassembly\n\n";

  // Verify we have all segments in order
  std::cout << "[SEGMENT VERIFICATION]\n";
  bool has_first = false, has_last = false;
  for (const auto &seg : segments) {
    std::cout << "  → Segment SI=" << si_field_to_string(seg->si)
              << ", SO=" << seg->so << ", Length=" << seg->data_length << "\n";
    if (seg->si == SI_Field::FIRST_SEGMENT)
      has_first = true;
    if (seg->si == SI_Field::LAST_SEGMENT)
      has_last = true;
  }

  if (!has_first || !has_last) {
    std::cout << "\n✗ ERROR: Missing first or last segment\n";
    return 0;
  }
  std::cout << "  ✓ All required segment types present\n\n";

  // Reassemble in order based on SO field
  std::cout << "[REASSEMBLY PROCESS]\n";
  size_t total_length = 0;

  for (const auto &seg : segments) {
    size_t offset = seg->so;
    std::cout << "  → Copying segment: SO=" << offset
              << ", Length=" << seg->data_length << " bytes\n";
    memcpy(reassembled + offset, seg->data, seg->data_length);
    total_length = std::max(total_length, offset + seg->data_length);
  }

  std::cout << "\n✓ REASSEMBLY COMPLETE\n";
  std::cout << "  → Total reassembled SDU length: " << total_length
            << " bytes\n\n";

  return total_length;
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 5: UMD PDU CONSTRUCTION
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Create UMD PDU from RLC segment
 */
void create_umd_pdu(const RLC_Segment *segment, uint8_t *pdu_buffer,
                    size_t &pdu_length) {

  UMD_PDU_Header header;
  header.si = segment->si;
  header.sn = segment->sn;
  header.so = segment->so;

  // Serialize header
  size_t header_size = header.get_header_size();
  header.serialize(pdu_buffer);

  // Copy data
  memcpy(pdu_buffer + header_size, segment->data, segment->data_length);
  pdu_length = header_size + segment->data_length;

  std::cout << "[UMD PDU CONSTRUCTION]\n";
  std::cout << "  → Header Size: " << header_size << " bytes\n";
  std::cout << "  → Payload Size: " << segment->data_length << " bytes\n";
  std::cout << "  → Total PDU Size: " << pdu_length << " bytes\n";

  // Show header breakdown
  std::cout << "\n  Header Breakdown (byte-by-byte):\n";
  for (size_t i = 0; i < header_size; i++) {
    std::cout << "    Byte " << i << ": 0x" << std::hex << std::setw(2)
              << std::setfill('0') << static_cast<int>(pdu_buffer[i])
              << std::dec << " = ";
    for (int b = 7; b >= 0; b--) {
      std::cout << ((pdu_buffer[i] >> b) & 1);
    }
    std::cout << "b";

    if (i == 0) {
      std::cout << "  [SI=" << static_cast<int>(segment->si)
                << ", SN[11:8]=" << ((pdu_buffer[i] & 0x0F)) << "]";
    } else if (i == 1 && header_size >= 2) {
      std::cout << "  [SN[7:0]=" << static_cast<int>(pdu_buffer[i]) << "]";
    } else if (i == 2 && header_size >= 4) {
      std::cout << "  [SO[15:8]=" << static_cast<int>(pdu_buffer[i]) << "]";
    } else if (i == 3 && header_size >= 4) {
      std::cout << "  [SO[7:0]=" << static_cast<int>(pdu_buffer[i]) << "]";
    }
    std::cout << "\n";
  }
  std::cout << "\n";
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 6: DEMONSTRATION SCENARIOS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Demonstrate SI and SO fields with different scenarios
 */
void demonstrate_segmentation() {

  std::cout << "\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "  5G NR RLC SEGMENTATION DEMONSTRATION\n";
  std::cout << "  SI (Segmentation Information) & SO (Segment Offset) Fields\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "Standard: 3GPP TS 38.322 v19.0.0 Release 19\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n\n";

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 1: Small SDU (No Segmentation)
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 1: Small SDU - No Segmentation Required             "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::string small_message = "Hello 5G!";
  uint8_t *small_sdu = new uint8_t[small_message.length()];
  string_to_bytes(small_message, small_sdu);

  std::cout << "Original SDU: \"" << small_message << "\"\n";
  std::cout << "SDU Length: " << small_message.length() << " bytes\n";
  print_hex("SDU Data", small_sdu, small_message.length());

  std::vector<RLC_Segment *> small_segments;
  segment_rlc_sdu(small_sdu, small_message.length(), 100, 100, small_segments,
                  false);

  // Create UMD PDU
  uint8_t pdu_buffer[200];
  size_t pdu_length;
  create_umd_pdu(small_segments[0], pdu_buffer, pdu_length);
  print_hex("Complete UMD PDU", pdu_buffer, pdu_length);

  // Cleanup
  for (auto seg : small_segments)
    delete seg;
  delete[] small_sdu;

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 2: Large SDU (Requires Segmentation)
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 2: Large SDU - Segmentation Required                "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::string large_message =
      "This is a much longer message that will require segmentation into "
      "multiple RLC PDUs. "
      "The RLC layer will use the SI field to indicate whether each PDU "
      "contains the first, "
      "middle, or last segment. The SO field indicates the byte position of "
      "each segment.";

  uint8_t *large_sdu = new uint8_t[large_message.length()];
  string_to_bytes(large_message, large_sdu);

  std::cout << "Original SDU: \"" << large_message << "\"\n";
  std::cout << "SDU Length: " << large_message.length() << " bytes\n";
  print_hex("SDU Data", large_sdu, large_message.length());

  std::vector<RLC_Segment *> large_segments;
  segment_rlc_sdu(large_sdu, large_message.length(), 200, 60, large_segments,
                  false);

  // Create UMD PDUs for each segment
  std::cout << "\n[PDU CONSTRUCTION FOR ALL SEGMENTS]\n\n";
  std::vector<uint8_t *> pdus;
  std::vector<size_t> pdu_sizes;

  for (size_t i = 0; i < large_segments.size(); i++) {
    std::cout
        << "═════════════════════════════════════════════════════════════\n";
    std::cout << "Segment #" << (i + 1) << " PDU\n";
    std::cout
        << "═════════════════════════════════════════════════════════════\n";

    uint8_t *pdu = new uint8_t[100];
    size_t len;
    create_umd_pdu(large_segments[i], pdu, len);
    print_hex("UMD PDU", pdu, len);

    pdus.push_back(pdu);
    pdu_sizes.push_back(len);
    std::cout << "\n";
  }

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 3: Reassembly
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 3: SDU Reassembly from Segments                     "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n";

  uint8_t *reassembled = new uint8_t[large_message.length()];
  size_t reassembled_length = reassemble_rlc_sdu(large_segments, reassembled);

  std::cout << "[REASSEMBLY VERIFICATION]\n";
  std::cout << "  → Original Length: " << large_message.length() << " bytes\n";
  std::cout << "  → Reassembled Length: " << reassembled_length << " bytes\n";
  print_hex("Reassembled SDU", reassembled, reassembled_length);

  std::string reassembled_str(reinterpret_cast<char *>(reassembled),
                              reassembled_length);
  std::cout << "  → Reassembled Message: \"" << reassembled_str << "\"\n";

  bool match = (reassembled_length == large_message.length()) &&
               (memcmp(large_sdu, reassembled, large_message.length()) == 0);
  std::cout << "\n  Verification: " << (match ? "✓ SUCCESS" : "✗ FAILED")
            << "\n";
  std::cout << "  → Reassembled SDU matches original: "
            << (match ? "YES" : "NO") << "\n\n";

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 4: SI and SO Field Reference Table
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SI FIELD REFERENCE (3GPP TS 38.322 Table 6.2.3.4-1)          "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::cout
      << "  ┌────────┬─────────────────────────────────────────┬──────────┐\n";
  std::cout
      << "  │ Value  │ Description                             │ SO Field │\n";
  std::cout
      << "  ├────────┼─────────────────────────────────────────┼──────────┤\n";
  std::cout
      << "  │  00b   │ Complete RLC SDU (no segmentation)      │    No    │\n";
  std::cout
      << "  │  01b   │ First segment of RLC SDU                │    No    │\n";
  std::cout
      << "  │  10b   │ Last segment of RLC SDU                 │   Yes    │\n";
  std::cout
      << "  │  11b   │ Middle segment of RLC SDU               │   Yes    │\n";
  std::cout
      << "  "
         "└────────┴─────────────────────────────────────────┴──────────┘\n\n";

  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SO FIELD SPECIFICATION (3GPP TS 38.322 Section 6.2.3.5)      "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::cout << "  Length: 16 bits\n";
  std::cout << "  Purpose: Indicates byte position within original RLC SDU\n";
  std::cout << "  Range: 0 - 65535 bytes\n";
  std::cout
      << "  Note: First byte of SDU is position 0 (numbering starts at zero)\n";
  std::cout << "  Special Value: 0xFFFF indicates \"to last byte of SDU\"\n\n";

  // Cleanup
  for (auto seg : large_segments)
    delete seg;
  for (auto pdu : pdus)
    delete[] pdu;
  delete[] large_sdu;
  delete[] reassembled;

  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "  DEMONSTRATION COMPLETE\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n\n";
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 7: MAIN FUNCTION
// ═══════════════════════════════════════════════════════════════════════════

int main() {
  demonstrate_segmentation();
  return 0;
} /**
   * ═══════════════════════════════════════════════════════════════════════════
   * 5G NR RLC SEGMENTATION - SI & SO FIELD DEMONSTRATION
   * ═══════════════════════════════════════════════════════════════════════════
   *
   * Standard Compliance: 3GPP TS 38.322 v19.0.0 (Radio Link Control Protocol)
   *
   * This implementation demonstrates RLC SDU segmentation with:
   *   - Segmentation Information (SI) field (2 bits)
   *   - Segment Offset (SO) field (16 bits)
   *   - Complete segmentation and reassembly procedures
   *
   * Focus Areas:
   *   1. SI Field (TS 38.322 Section 6.2.3.4): Indicates segment type
   *   2. SO Field (TS 38.322 Section 6.2.3.5): Indicates byte position
   *   3. UMD/AMD PDU Construction (Section 6.2.2.3/6.2.2.4)
   *   4. Segmentation Procedures (Section 4.2.1.2/4.2.1.3)
   *
   * Author: 5G RLC Protocol Implementation
   * Date: February 2026
   * ═══════════════════════════════════════════════════════════════════════════
   */

#include <cstdint>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: SEGMENTATION INFORMATION (SI) FIELD DEFINITIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Segmentation Information (SI) field values
 *
 * As per 3GPP TS 38.322 Section 6.2.3.4, Table 6.2.3.4-1
 * Length: 2 bits
 *
 * The SI field indicates whether an RLC PDU contains:
 * - A complete RLC SDU (no segmentation)
 * - The first segment of an RLC SDU
 * - The last segment of an RLC SDU
 * - A middle segment of an RLC SDU
 */
enum class SI_Field : uint8_t {
  COMPLETE_SDU = 0x00, // 00b - Data field contains all bytes of an RLC SDU
  FIRST_SEGMENT =
      0x01, // 01b - Data field contains the first segment of an RLC SDU
  LAST_SEGMENT =
      0x02, // 10b - Data field contains the last segment of an RLC SDU
  MIDDLE_SEGMENT =
      0x03 // 11b - Data field contains neither first nor last segment
};

/**
 * @brief Convert SI field value to string representation
 */
const char *si_field_to_string(SI_Field si) {
  switch (si) {
  case SI_Field::COMPLETE_SDU:
    return "COMPLETE SDU (00b)";
  case SI_Field::FIRST_SEGMENT:
    return "FIRST SEGMENT (01b)";
  case SI_Field::LAST_SEGMENT:
    return "LAST SEGMENT (10b)";
  case SI_Field::MIDDLE_SEGMENT:
    return "MIDDLE SEGMENT (11b)";
  default:
    return "UNKNOWN";
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2: RLC PDU STRUCTURES (3GPP TS 38.322 Section 6.2)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief RLC UMD PDU Header Structure (12-bit SN with SO)
 *
 * As per 3GPP TS 38.322 Section 6.2.2.3, Figure 6.2.2.3-5
 *
 * Byte 0:  SI (2 bits) | R (2 bits) | SN[11:8] (4 bits)
 * Byte 1:  SN[7:0] (8 bits)
 * Byte 2:  SO[15:8] (8 bits)  [Only if segment, not first]
 * Byte 3:  SO[7:0] (8 bits)   [Only if segment, not first]
 */
struct UMD_PDU_Header {
  SI_Field si; // Segmentation Information (2 bits)
  uint16_t sn; // Sequence Number (12 bits for UM)
  uint16_t so; // Segment Offset (16 bits) - present only for segments
  bool has_so; // Indicates if SO field is present

  UMD_PDU_Header() : si(SI_Field::COMPLETE_SDU), sn(0), so(0), has_so(false) {}

  /**
   * @brief Get header size in bytes
   */
  size_t get_header_size() const {
    if (si == SI_Field::COMPLETE_SDU) {
      return 1; // Only SI field (with padding)
    } else if (si == SI_Field::FIRST_SEGMENT) {
      return 2; // SI + SN (no SO for first segment)
    } else {
      return 4; // SI + SN + SO (for middle/last segments)
    }
  }

  /**
   * @brief Serialize header to byte array
   */
  void serialize(uint8_t *buffer) const {
    if (si == SI_Field::COMPLETE_SDU) {
      // TS 38.322 Figure 6.2.2.3-1: UMD PDU containing complete SDU
      buffer[0] = (static_cast<uint8_t>(si) << 6); // SI in bits 7-6
      // Bits 5-0 are reserved (R fields)
    } else if (si == SI_Field::FIRST_SEGMENT) {
      // TS 38.322 Figure 6.2.2.3-3: UMD PDU with 12-bit SN (No SO)
      buffer[0] = (static_cast<uint8_t>(si) << 6) | // SI in bits 7-6
                  ((sn >> 8) & 0x0F);               // SN[11:8] in bits 3-0
      buffer[1] = sn & 0xFF;                        // SN[7:0]
    } else {
      // TS 38.322 Figure 6.2.2.3-5: UMD PDU with 12-bit SN and SO
      buffer[0] = (static_cast<uint8_t>(si) << 6) | // SI in bits 7-6
                  ((sn >> 8) & 0x0F);               // SN[11:8] in bits 3-0
      buffer[1] = sn & 0xFF;                        // SN[7:0]
      buffer[2] = (so >> 8) & 0xFF;                 // SO[15:8]
      buffer[3] = so & 0xFF;                        // SO[7:0]
    }
  }

  /**
   * @brief Deserialize header from byte array
   */
  void deserialize(const uint8_t *buffer) {
    // Extract SI field (bits 7-6 of first byte)
    si = static_cast<SI_Field>((buffer[0] >> 6) & 0x03);

    if (si == SI_Field::COMPLETE_SDU) {
      sn = 0;
      so = 0;
      has_so = false;
    } else if (si == SI_Field::FIRST_SEGMENT) {
      // Extract 12-bit SN
      sn = ((buffer[0] & 0x0F) << 8) | buffer[1];
      so = 0;
      has_so = false;
    } else {
      // Extract 12-bit SN and 16-bit SO
      sn = ((buffer[0] & 0x0F) << 8) | buffer[1];
      so = (buffer[2] << 8) | buffer[3];
      has_so = true;
    }
  }
};

/**
 * @brief RLC AMD PDU Header Structure (12-bit SN with SO)
 *
 * As per 3GPP TS 38.322 Section 6.2.2.4, Figure 6.2.2.4-3
 *
 * Byte 0:  D/C (1 bit) | P (1 bit) | SI (2 bits) | SN[11:8] (4 bits)
 * Byte 1:  SN[7:0] (8 bits)
 * Byte 2:  SO[15:8] (8 bits)  [Only if segment, not first]
 * Byte 3:  SO[7:0] (8 bits)   [Only if segment, not first]
 */
struct AMD_PDU_Header {
  uint8_t dc;  // Data/Control field (1 bit) - always 1 for data
  uint8_t p;   // Polling bit (1 bit)
  SI_Field si; // Segmentation Information (2 bits)
  uint16_t sn; // Sequence Number (12 bits for AM)
  uint16_t so; // Segment Offset (16 bits)
  bool has_so; // Indicates if SO field is present

  AMD_PDU_Header()
      : dc(1), p(0), si(SI_Field::COMPLETE_SDU), sn(0), so(0), has_so(false) {}

  /**
   * @brief Get header size in bytes
   */
  size_t get_header_size() const {
    if (si == SI_Field::COMPLETE_SDU || si == SI_Field::FIRST_SEGMENT) {
      return 2; // D/C + P + SI + SN (no SO)
    } else {
      return 4; // D/C + P + SI + SN + SO
    }
  }

  /**
   * @brief Serialize header to byte array
   */
  void serialize(uint8_t *buffer) const {
    // TS 38.322 Section 6.2.2.4
    buffer[0] = (dc << 7) |                       // D/C bit
                (p << 6) |                        // P bit
                (static_cast<uint8_t>(si) << 4) | // SI field
                ((sn >> 8) & 0x0F);               // SN[11:8]
    buffer[1] = sn & 0xFF;                        // SN[7:0]

    if (si == SI_Field::MIDDLE_SEGMENT || si == SI_Field::LAST_SEGMENT) {
      buffer[2] = (so >> 8) & 0xFF; // SO[15:8]
      buffer[3] = so & 0xFF;        // SO[7:0]
    }
  }

  /**
   * @brief Deserialize header from byte array
   */
  void deserialize(const uint8_t *buffer) {
    dc = (buffer[0] >> 7) & 0x01;
    p = (buffer[0] >> 6) & 0x01;
    si = static_cast<SI_Field>((buffer[0] >> 4) & 0x03);
    sn = ((buffer[0] & 0x0F) << 8) | buffer[1];

    if (si == SI_Field::MIDDLE_SEGMENT || si == SI_Field::LAST_SEGMENT) {
      so = (buffer[2] << 8) | buffer[3];
      has_so = true;
    } else {
      so = 0;
      has_so = false;
    }
  }
};

/**
 * @brief RLC SDU Segment Structure
 */
struct RLC_Segment {
  SI_Field si;              // Segment type
  uint16_t sn;              // Sequence number
  uint16_t so;              // Segment offset (byte position in original SDU)
  uint8_t *data;            // Segment data
  size_t data_length;       // Length of segment data
  size_t original_sdu_size; // Total size of original SDU

  RLC_Segment()
      : si(SI_Field::COMPLETE_SDU), sn(0), so(0), data(nullptr), data_length(0),
        original_sdu_size(0) {}

  ~RLC_Segment() {
    if (data) {
      delete[] data;
    }
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3: UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Print hex dump of byte array
 */
void print_hex(const std::string &label, const uint8_t *data, size_t length) {
  std::cout << label << " (" << length << " bytes):\n  0x";
  for (size_t i = 0; i < length; i++) {
    std::cout << std::hex << std::setw(2) << std::setfill('0')
              << static_cast<int>(data[i]);
    if ((i + 1) % 32 == 0 && i + 1 < length)
      std::cout << "\n  0x";
  }
  std::cout << std::dec << "\n";
}

/**
 * @brief Print binary representation of byte
 */
void print_binary(const std::string &label, uint8_t byte) {
  std::cout << label << ": ";
  for (int i = 7; i >= 0; i--) {
    std::cout << ((byte >> i) & 1);
  }
  std::cout << "b\n";
}

/**
 * @brief Convert string to bytes
 */
void string_to_bytes(const std::string &str, uint8_t *output) {
  for (size_t i = 0; i < str.length(); i++) {
    output[i] = static_cast<uint8_t>(str[i]);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4: RLC SEGMENTATION ENGINE
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Segment an RLC SDU into multiple segments
 *
 * As per 3GPP TS 38.322 Section 4.2.1.2.2 and 4.2.1.3.2
 *
 * @param sdu           Original RLC SDU data
 * @param sdu_length    Length of original SDU
 * @param sn            Sequence number to assign
 * @param max_pdu_size  Maximum PDU size (including header)
 * @param segments      [out] Vector of created segments
 * @param is_am         True for AM mode, False for UM mode
 */
void segment_rlc_sdu(const uint8_t *sdu, size_t sdu_length, uint16_t sn,
                     size_t max_pdu_size, std::vector<RLC_Segment *> &segments,
                     bool is_am = false) {

  std::cout << "\n";
  std::cout
      << "╔═══════════════════════════════════════════════════════════════╗\n";
  std::cout
      << "║  RLC SDU SEGMENTATION PROCESS                                 ║\n";
  std::cout
      << "╚═══════════════════════════════════════════════════════════════╝\n";
  std::cout << "3GPP Reference: TS 38.322 Section 4.2.1.2.2/4.2.1.3.2\n\n";

  std::cout << "[SEGMENTATION INPUT]\n";
  std::cout << "  → Original SDU Length: " << sdu_length << " bytes\n";
  std::cout << "  → Sequence Number (SN): " << sn << "\n";
  std::cout << "  → Max PDU Size: " << max_pdu_size << " bytes\n";
  std::cout << "  → Mode: " << (is_am ? "AM" : "UM") << "\n\n";

  // Calculate header sizes for different segment types
  size_t first_segment_header_size = is_am ? 2 : 2; // No SO field
  size_t other_segment_header_size = is_am ? 4 : 4; // With SO field

  // Calculate available payload sizes
  size_t first_segment_payload = max_pdu_size - first_segment_header_size;
  size_t other_segment_payload = max_pdu_size - other_segment_header_size;

  std::cout << "[HEADER SIZE CALCULATION]\n";
  std::cout << "  → First Segment Header: " << first_segment_header_size
            << " bytes (SI + SN, no SO)\n";
  std::cout << "  → Other Segment Header: " << other_segment_header_size
            << " bytes (SI + SN + SO)\n";
  std::cout << "  → First Segment Payload: " << first_segment_payload
            << " bytes\n";
  std::cout << "  → Other Segment Payload: " << other_segment_payload
            << " bytes\n\n";

  // Check if segmentation is needed
  if (sdu_length + first_segment_header_size <= max_pdu_size) {
    std::cout << "[SEGMENTATION DECISION] No segmentation needed\n";
    std::cout << "  → SDU fits in single PDU\n\n";

    RLC_Segment *segment = new RLC_Segment();
    segment->si = SI_Field::COMPLETE_SDU;
    segment->sn = sn;
    segment->so = 0;
    segment->data_length = sdu_length;
    segment->original_sdu_size = sdu_length;
    segment->data = new uint8_t[sdu_length];
    memcpy(segment->data, sdu, sdu_length);
    segments.push_back(segment);
    return;
  }

  std::cout << "[SEGMENTATION DECISION] Segmentation required\n";
  std::cout << "  → SDU will be split into multiple segments\n\n";

  // Calculate number of segments needed
  size_t remaining = sdu_length;
  size_t offset = 0;
  int segment_count = 0;

  // First segment
  size_t first_chunk = std::min(first_segment_payload, remaining);
  remaining -= first_chunk;
  segment_count++;

  // Calculate remaining segments
  while (remaining > 0) {
    size_t chunk = std::min(other_segment_payload, remaining);
    remaining -= chunk;
    segment_count++;
  }

  std::cout << "[SEGMENT CALCULATION]\n";
  std::cout << "  → Total segments needed: " << segment_count << "\n\n";

  // Create segments
  remaining = sdu_length;
  offset = 0;

  for (int i = 0; i < segment_count; i++) {
    RLC_Segment *segment = new RLC_Segment();
    segment->sn = sn;
    segment->original_sdu_size = sdu_length;

    // Determine SI field and data length
    if (i == 0) {
      // First segment
      segment->si = SI_Field::FIRST_SEGMENT;
      segment->so = 0; // SO not included in first segment
      segment->data_length = std::min(first_segment_payload, remaining);
    } else if (i == segment_count - 1) {
      // Last segment
      segment->si = SI_Field::LAST_SEGMENT;
      segment->so = offset;
      segment->data_length = remaining;
    } else {
      // Middle segment
      segment->si = SI_Field::MIDDLE_SEGMENT;
      segment->so = offset;
      segment->data_length = std::min(other_segment_payload, remaining);
    }

    // Copy data
    segment->data = new uint8_t[segment->data_length];
    memcpy(segment->data, sdu + offset, segment->data_length);

    std::cout
        << "─────────────────────────────────────────────────────────────\n";
    std::cout << "[SEGMENT #" << (i + 1) << "]\n";
    std::cout << "  → SI Field: " << si_field_to_string(segment->si) << "\n";
    std::cout << "  → SN: " << segment->sn << "\n";
    std::cout << "  → SO: " << segment->so << " bytes";
    if (segment->si == SI_Field::FIRST_SEGMENT) {
      std::cout << " (not included in header)";
    }
    std::cout << "\n";
    std::cout << "  → Data Length: " << segment->data_length << " bytes\n";
    std::cout << "  → Byte Range: [" << offset << " - "
              << (offset + segment->data_length - 1) << "]\n";
    std::cout << "  → Header Size: "
              << (segment->si == SI_Field::FIRST_SEGMENT
                      ? first_segment_header_size
                      : other_segment_header_size)
              << " bytes\n";
    std::cout << "  → Total PDU Size: "
              << (segment->data_length + (segment->si == SI_Field::FIRST_SEGMENT
                                              ? first_segment_header_size
                                              : other_segment_header_size))
              << " bytes\n";

    segments.push_back(segment);
    offset += segment->data_length;
    remaining -= segment->data_length;
  }

  std::cout
      << "─────────────────────────────────────────────────────────────\n";
  std::cout << "\n✓ SEGMENTATION COMPLETE\n";
  std::cout << "  → Created " << segment_count
            << " segments from original SDU\n";
  std::cout << "  → Total bytes segmented: " << sdu_length << "\n\n";
}

/**
 * @brief Reassemble RLC SDU from segments
 *
 * As per 3GPP TS 38.322 Section 5.2.2.2.3 and 5.2.3.2.3
 *
 * @param segments      Vector of received segments
 * @param reassembled   [out] Reassembled SDU buffer
 * @return              Length of reassembled SDU, or 0 on failure
 */
size_t reassemble_rlc_sdu(const std::vector<RLC_Segment *> &segments,
                          uint8_t *reassembled) {

  std::cout << "\n";
  std::cout
      << "╔═══════════════════════════════════════════════════════════════╗\n";
  std::cout
      << "║  RLC SDU REASSEMBLY PROCESS                                   ║\n";
  std::cout
      << "╚═══════════════════════════════════════════════════════════════╝\n";
  std::cout << "3GPP Reference: TS 38.322 Section 5.2.2.2.3/5.2.3.2.3\n\n";

  if (segments.empty()) {
    std::cout << "✗ ERROR: No segments to reassemble\n";
    return 0;
  }

  std::cout << "[REASSEMBLY INPUT]\n";
  std::cout << "  → Number of segments: " << segments.size() << "\n";
  std::cout << "  → Sequence Number: " << segments[0]->sn << "\n\n";

  // Check if we have a complete SDU (no segmentation)
  if (segments.size() == 1 && segments[0]->si == SI_Field::COMPLETE_SDU) {
    std::cout << "[REASSEMBLY TYPE] Complete SDU (no segmentation)\n";
    memcpy(reassembled, segments[0]->data, segments[0]->data_length);
    std::cout << "  → SDU Length: " << segments[0]->data_length << " bytes\n";
    std::cout << "\n✓ REASSEMBLY COMPLETE\n\n";
    return segments[0]->data_length;
  }

  std::cout << "[REASSEMBLY TYPE] Segmented SDU reassembly\n\n";

  // Verify we have all segments in order
  std::cout << "[SEGMENT VERIFICATION]\n";
  bool has_first = false, has_last = false;
  for (const auto &seg : segments) {
    std::cout << "  → Segment SI=" << si_field_to_string(seg->si)
              << ", SO=" << seg->so << ", Length=" << seg->data_length << "\n";
    if (seg->si == SI_Field::FIRST_SEGMENT)
      has_first = true;
    if (seg->si == SI_Field::LAST_SEGMENT)
      has_last = true;
  }

  if (!has_first || !has_last) {
    std::cout << "\n✗ ERROR: Missing first or last segment\n";
    return 0;
  }
  std::cout << "  ✓ All required segment types present\n\n";

  // Reassemble in order based on SO field
  std::cout << "[REASSEMBLY PROCESS]\n";
  size_t total_length = 0;

  for (const auto &seg : segments) {
    size_t offset = seg->so;
    std::cout << "  → Copying segment: SO=" << offset
              << ", Length=" << seg->data_length << " bytes\n";
    memcpy(reassembled + offset, seg->data, seg->data_length);
    total_length = std::max(total_length, offset + seg->data_length);
  }

  std::cout << "\n✓ REASSEMBLY COMPLETE\n";
  std::cout << "  → Total reassembled SDU length: " << total_length
            << " bytes\n\n";

  return total_length;
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 5: UMD PDU CONSTRUCTION
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Create UMD PDU from RLC segment
 */
void create_umd_pdu(const RLC_Segment *segment, uint8_t *pdu_buffer,
                    size_t &pdu_length) {

  UMD_PDU_Header header;
  header.si = segment->si;
  header.sn = segment->sn;
  header.so = segment->so;

  // Serialize header
  size_t header_size = header.get_header_size();
  header.serialize(pdu_buffer);

  // Copy data
  memcpy(pdu_buffer + header_size, segment->data, segment->data_length);
  pdu_length = header_size + segment->data_length;

  std::cout << "[UMD PDU CONSTRUCTION]\n";
  std::cout << "  → Header Size: " << header_size << " bytes\n";
  std::cout << "  → Payload Size: " << segment->data_length << " bytes\n";
  std::cout << "  → Total PDU Size: " << pdu_length << " bytes\n";

  // Show header breakdown
  std::cout << "\n  Header Breakdown (byte-by-byte):\n";
  for (size_t i = 0; i < header_size; i++) {
    std::cout << "    Byte " << i << ": 0x" << std::hex << std::setw(2)
              << std::setfill('0') << static_cast<int>(pdu_buffer[i])
              << std::dec << " = ";
    for (int b = 7; b >= 0; b--) {
      std::cout << ((pdu_buffer[i] >> b) & 1);
    }
    std::cout << "b";

    if (i == 0) {
      std::cout << "  [SI=" << static_cast<int>(segment->si)
                << ", SN[11:8]=" << ((pdu_buffer[i] & 0x0F)) << "]";
    } else if (i == 1 && header_size >= 2) {
      std::cout << "  [SN[7:0]=" << static_cast<int>(pdu_buffer[i]) << "]";
    } else if (i == 2 && header_size >= 4) {
      std::cout << "  [SO[15:8]=" << static_cast<int>(pdu_buffer[i]) << "]";
    } else if (i == 3 && header_size >= 4) {
      std::cout << "  [SO[7:0]=" << static_cast<int>(pdu_buffer[i]) << "]";
    }
    std::cout << "\n";
  }
  std::cout << "\n";
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 6: DEMONSTRATION SCENARIOS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Demonstrate SI and SO fields with different scenarios
 */
void demonstrate_segmentation() {

  std::cout << "\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "  5G NR RLC SEGMENTATION DEMONSTRATION\n";
  std::cout << "  SI (Segmentation Information) & SO (Segment Offset) Fields\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "Standard: 3GPP TS 38.322 v19.0.0 Release 19\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n\n";

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 1: Small SDU (No Segmentation)
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 1: Small SDU - No Segmentation Required             "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::string small_message = "Hello 5G!";
  uint8_t *small_sdu = new uint8_t[small_message.length()];
  string_to_bytes(small_message, small_sdu);

  std::cout << "Original SDU: \"" << small_message << "\"\n";
  std::cout << "SDU Length: " << small_message.length() << " bytes\n";
  print_hex("SDU Data", small_sdu, small_message.length());

  std::vector<RLC_Segment *> small_segments;
  segment_rlc_sdu(small_sdu, small_message.length(), 100, 100, small_segments,
                  false);

  // Create UMD PDU
  uint8_t pdu_buffer[200];
  size_t pdu_length;
  create_umd_pdu(small_segments[0], pdu_buffer, pdu_length);
  print_hex("Complete UMD PDU", pdu_buffer, pdu_length);

  // Cleanup
  for (auto seg : small_segments)
    delete seg;
  delete[] small_sdu;

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 2: Large SDU (Requires Segmentation)
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 2: Large SDU - Segmentation Required                "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::string large_message =
      "This is a much longer message that will require segmentation into "
      "multiple RLC PDUs. "
      "The RLC layer will use the SI field to indicate whether each PDU "
      "contains the first, "
      "middle, or last segment. The SO field indicates the byte position of "
      "each segment.";

  uint8_t *large_sdu = new uint8_t[large_message.length()];
  string_to_bytes(large_message, large_sdu);

  std::cout << "Original SDU: \"" << large_message << "\"\n";
  std::cout << "SDU Length: " << large_message.length() << " bytes\n";
  print_hex("SDU Data", large_sdu, large_message.length());

  std::vector<RLC_Segment *> large_segments;
  segment_rlc_sdu(large_sdu, large_message.length(), 200, 60, large_segments,
                  false);

  // Create UMD PDUs for each segment
  std::cout << "\n[PDU CONSTRUCTION FOR ALL SEGMENTS]\n\n";
  std::vector<uint8_t *> pdus;
  std::vector<size_t> pdu_sizes;

  for (size_t i = 0; i < large_segments.size(); i++) {
    std::cout
        << "═════════════════════════════════════════════════════════════\n";
    std::cout << "Segment #" << (i + 1) << " PDU\n";
    std::cout
        << "═════════════════════════════════════════════════════════════\n";

    uint8_t *pdu = new uint8_t[100];
    size_t len;
    create_umd_pdu(large_segments[i], pdu, len);
    print_hex("UMD PDU", pdu, len);

    pdus.push_back(pdu);
    pdu_sizes.push_back(len);
    std::cout << "\n";
  }

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 3: Reassembly
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 3: SDU Reassembly from Segments                     "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n";

  uint8_t *reassembled = new uint8_t[large_message.length()];
  size_t reassembled_length = reassemble_rlc_sdu(large_segments, reassembled);

  std::cout << "[REASSEMBLY VERIFICATION]\n";
  std::cout << "  → Original Length: " << large_message.length() << " bytes\n";
  std::cout << "  → Reassembled Length: " << reassembled_length << " bytes\n";
  print_hex("Reassembled SDU", reassembled, reassembled_length);

  std::string reassembled_str(reinterpret_cast<char *>(reassembled),
                              reassembled_length);
  std::cout << "  → Reassembled Message: \"" << reassembled_str << "\"\n";

  bool match = (reassembled_length == large_message.length()) &&
               (memcmp(large_sdu, reassembled, large_message.length()) == 0);
  std::cout << "\n  Verification: " << (match ? "✓ SUCCESS" : "✗ FAILED")
            << "\n";
  std::cout << "  → Reassembled SDU matches original: "
            << (match ? "YES" : "NO") << "\n\n";

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 4: SI and SO Field Reference Table
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SI FIELD REFERENCE (3GPP TS 38.322 Table 6.2.3.4-1)          "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::cout
      << "  ┌────────┬─────────────────────────────────────────┬──────────┐\n";
  std::cout
      << "  │ Value  │ Description                             │ SO Field │\n";
  std::cout
      << "  ├────────┼─────────────────────────────────────────┼──────────┤\n";
  std::cout
      << "  │  00b   │ Complete RLC SDU (no segmentation)      │    No    │\n";
  std::cout
      << "  │  01b   │ First segment of RLC SDU                │    No    │\n";
  std::cout
      << "  │  10b   │ Last segment of RLC SDU                 │   Yes    │\n";
  std::cout
      << "  │  11b   │ Middle segment of RLC SDU               │   Yes    │\n";
  std::cout
      << "  "
         "└────────┴─────────────────────────────────────────┴──────────┘\n\n";

  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SO FIELD SPECIFICATION (3GPP TS 38.322 Section 6.2.3.5)      "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::cout << "  Length: 16 bits\n";
  std::cout << "  Purpose: Indicates byte position within original RLC SDU\n";
  std::cout << "  Range: 0 - 65535 bytes\n";
  std::cout
      << "  Note: First byte of SDU is position 0 (numbering starts at zero)\n";
  std::cout << "  Special Value: 0xFFFF indicates \"to last byte of SDU\"\n\n";

  // Cleanup
  for (auto seg : large_segments)
    delete seg;
  for (auto pdu : pdus)
    delete[] pdu;
  delete[] large_sdu;
  delete[] reassembled;

  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "  DEMONSTRATION COMPLETE\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n\n";
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 7: MAIN FUNCTION
// ═══════════════════════════════════════════════════════════════════════════

int main() {
  demonstrate_segmentation();
  return 0;
} /**
   * ═══════════════════════════════════════════════════════════════════════════
   * 5G NR RLC SEGMENTATION - SI & SO FIELD DEMONSTRATION
   * ═══════════════════════════════════════════════════════════════════════════
   *
   * Standard Compliance: 3GPP TS 38.322 v19.0.0 (Radio Link Control Protocol)
   *
   * This implementation demonstrates RLC SDU segmentation with:
   *   - Segmentation Information (SI) field (2 bits)
   *   - Segment Offset (SO) field (16 bits)
   *   - Complete segmentation and reassembly procedures
   *
   * Focus Areas:
   *   1. SI Field (TS 38.322 Section 6.2.3.4): Indicates segment type
   *   2. SO Field (TS 38.322 Section 6.2.3.5): Indicates byte position
   *   3. UMD/AMD PDU Construction (Section 6.2.2.3/6.2.2.4)
   *   4. Segmentation Procedures (Section 4.2.1.2/4.2.1.3)
   *
   * Author: 5G RLC Protocol Implementation
   * Date: February 2026
   * ═══════════════════════════════════════════════════════════════════════════
   */

#include <cstdint>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: SEGMENTATION INFORMATION (SI) FIELD DEFINITIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Segmentation Information (SI) field values
 *
 * As per 3GPP TS 38.322 Section 6.2.3.4, Table 6.2.3.4-1
 * Length: 2 bits
 *
 * The SI field indicates whether an RLC PDU contains:
 * - A complete RLC SDU (no segmentation)
 * - The first segment of an RLC SDU
 * - The last segment of an RLC SDU
 * - A middle segment of an RLC SDU
 */
enum class SI_Field : uint8_t {
  COMPLETE_SDU = 0x00, // 00b - Data field contains all bytes of an RLC SDU
  FIRST_SEGMENT =
      0x01, // 01b - Data field contains the first segment of an RLC SDU
  LAST_SEGMENT =
      0x02, // 10b - Data field contains the last segment of an RLC SDU
  MIDDLE_SEGMENT =
      0x03 // 11b - Data field contains neither first nor last segment
};

/**
 * @brief Convert SI field value to string representation
 */
const char *si_field_to_string(SI_Field si) {
  switch (si) {
  case SI_Field::COMPLETE_SDU:
    return "COMPLETE SDU (00b)";
  case SI_Field::FIRST_SEGMENT:
    return "FIRST SEGMENT (01b)";
  case SI_Field::LAST_SEGMENT:
    return "LAST SEGMENT (10b)";
  case SI_Field::MIDDLE_SEGMENT:
    return "MIDDLE SEGMENT (11b)";
  default:
    return "UNKNOWN";
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2: RLC PDU STRUCTURES (3GPP TS 38.322 Section 6.2)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief RLC UMD PDU Header Structure (12-bit SN with SO)
 *
 * As per 3GPP TS 38.322 Section 6.2.2.3, Figure 6.2.2.3-5
 *
 * Byte 0:  SI (2 bits) | R (2 bits) | SN[11:8] (4 bits)
 * Byte 1:  SN[7:0] (8 bits)
 * Byte 2:  SO[15:8] (8 bits)  [Only if segment, not first]
 * Byte 3:  SO[7:0] (8 bits)   [Only if segment, not first]
 */
struct UMD_PDU_Header {
  SI_Field si; // Segmentation Information (2 bits)
  uint16_t sn; // Sequence Number (12 bits for UM)
  uint16_t so; // Segment Offset (16 bits) - present only for segments
  bool has_so; // Indicates if SO field is present

  UMD_PDU_Header() : si(SI_Field::COMPLETE_SDU), sn(0), so(0), has_so(false) {}

  /**
   * @brief Get header size in bytes
   */
  size_t get_header_size() const {
    if (si == SI_Field::COMPLETE_SDU) {
      return 1; // Only SI field (with padding)
    } else if (si == SI_Field::FIRST_SEGMENT) {
      return 2; // SI + SN (no SO for first segment)
    } else {
      return 4; // SI + SN + SO (for middle/last segments)
    }
  }

  /**
   * @brief Serialize header to byte array
   */
  void serialize(uint8_t *buffer) const {
    if (si == SI_Field::COMPLETE_SDU) {
      // TS 38.322 Figure 6.2.2.3-1: UMD PDU containing complete SDU
      buffer[0] = (static_cast<uint8_t>(si) << 6); // SI in bits 7-6
      // Bits 5-0 are reserved (R fields)
    } else if (si == SI_Field::FIRST_SEGMENT) {
      // TS 38.322 Figure 6.2.2.3-3: UMD PDU with 12-bit SN (No SO)
      buffer[0] = (static_cast<uint8_t>(si) << 6) | // SI in bits 7-6
                  ((sn >> 8) & 0x0F);               // SN[11:8] in bits 3-0
      buffer[1] = sn & 0xFF;                        // SN[7:0]
    } else {
      // TS 38.322 Figure 6.2.2.3-5: UMD PDU with 12-bit SN and SO
      buffer[0] = (static_cast<uint8_t>(si) << 6) | // SI in bits 7-6
                  ((sn >> 8) & 0x0F);               // SN[11:8] in bits 3-0
      buffer[1] = sn & 0xFF;                        // SN[7:0]
      buffer[2] = (so >> 8) & 0xFF;                 // SO[15:8]
      buffer[3] = so & 0xFF;                        // SO[7:0]
    }
  }

  /**
   * @brief Deserialize header from byte array
   */
  void deserialize(const uint8_t *buffer) {
    // Extract SI field (bits 7-6 of first byte)
    si = static_cast<SI_Field>((buffer[0] >> 6) & 0x03);

    if (si == SI_Field::COMPLETE_SDU) {
      sn = 0;
      so = 0;
      has_so = false;
    } else if (si == SI_Field::FIRST_SEGMENT) {
      // Extract 12-bit SN
      sn = ((buffer[0] & 0x0F) << 8) | buffer[1];
      so = 0;
      has_so = false;
    } else {
      // Extract 12-bit SN and 16-bit SO
      sn = ((buffer[0] & 0x0F) << 8) | buffer[1];
      so = (buffer[2] << 8) | buffer[3];
      has_so = true;
    }
  }
};

/**
 * @brief RLC AMD PDU Header Structure (12-bit SN with SO)
 *
 * As per 3GPP TS 38.322 Section 6.2.2.4, Figure 6.2.2.4-3
 *
 * Byte 0:  D/C (1 bit) | P (1 bit) | SI (2 bits) | SN[11:8] (4 bits)
 * Byte 1:  SN[7:0] (8 bits)
 * Byte 2:  SO[15:8] (8 bits)  [Only if segment, not first]
 * Byte 3:  SO[7:0] (8 bits)   [Only if segment, not first]
 */
struct AMD_PDU_Header {
  uint8_t dc;  // Data/Control field (1 bit) - always 1 for data
  uint8_t p;   // Polling bit (1 bit)
  SI_Field si; // Segmentation Information (2 bits)
  uint16_t sn; // Sequence Number (12 bits for AM)
  uint16_t so; // Segment Offset (16 bits)
  bool has_so; // Indicates if SO field is present

  AMD_PDU_Header()
      : dc(1), p(0), si(SI_Field::COMPLETE_SDU), sn(0), so(0), has_so(false) {}

  /**
   * @brief Get header size in bytes
   */
  size_t get_header_size() const {
    if (si == SI_Field::COMPLETE_SDU || si == SI_Field::FIRST_SEGMENT) {
      return 2; // D/C + P + SI + SN (no SO)
    } else {
      return 4; // D/C + P + SI + SN + SO
    }
  }

  /**
   * @brief Serialize header to byte array
   */
  void serialize(uint8_t *buffer) const {
    // TS 38.322 Section 6.2.2.4
    buffer[0] = (dc << 7) |                       // D/C bit
                (p << 6) |                        // P bit
                (static_cast<uint8_t>(si) << 4) | // SI field
                ((sn >> 8) & 0x0F);               // SN[11:8]
    buffer[1] = sn & 0xFF;                        // SN[7:0]

    if (si == SI_Field::MIDDLE_SEGMENT || si == SI_Field::LAST_SEGMENT) {
      buffer[2] = (so >> 8) & 0xFF; // SO[15:8]
      buffer[3] = so & 0xFF;        // SO[7:0]
    }
  }

  /**
   * @brief Deserialize header from byte array
   */
  void deserialize(const uint8_t *buffer) {
    dc = (buffer[0] >> 7) & 0x01;
    p = (buffer[0] >> 6) & 0x01;
    si = static_cast<SI_Field>((buffer[0] >> 4) & 0x03);
    sn = ((buffer[0] & 0x0F) << 8) | buffer[1];

    if (si == SI_Field::MIDDLE_SEGMENT || si == SI_Field::LAST_SEGMENT) {
      so = (buffer[2] << 8) | buffer[3];
      has_so = true;
    } else {
      so = 0;
      has_so = false;
    }
  }
};

/**
 * @brief RLC SDU Segment Structure
 */
struct RLC_Segment {
  SI_Field si;              // Segment type
  uint16_t sn;              // Sequence number
  uint16_t so;              // Segment offset (byte position in original SDU)
  uint8_t *data;            // Segment data
  size_t data_length;       // Length of segment data
  size_t original_sdu_size; // Total size of original SDU

  RLC_Segment()
      : si(SI_Field::COMPLETE_SDU), sn(0), so(0), data(nullptr), data_length(0),
        original_sdu_size(0) {}

  ~RLC_Segment() {
    if (data) {
      delete[] data;
    }
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3: UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Print hex dump of byte array
 */
void print_hex(const std::string &label, const uint8_t *data, size_t length) {
  std::cout << label << " (" << length << " bytes):\n  0x";
  for (size_t i = 0; i < length; i++) {
    std::cout << std::hex << std::setw(2) << std::setfill('0')
              << static_cast<int>(data[i]);
    if ((i + 1) % 32 == 0 && i + 1 < length)
      std::cout << "\n  0x";
  }
  std::cout << std::dec << "\n";
}

/**
 * @brief Print binary representation of byte
 */
void print_binary(const std::string &label, uint8_t byte) {
  std::cout << label << ": ";
  for (int i = 7; i >= 0; i--) {
    std::cout << ((byte >> i) & 1);
  }
  std::cout << "b\n";
}

/**
 * @brief Convert string to bytes
 */
void string_to_bytes(const std::string &str, uint8_t *output) {
  for (size_t i = 0; i < str.length(); i++) {
    output[i] = static_cast<uint8_t>(str[i]);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4: RLC SEGMENTATION ENGINE
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Segment an RLC SDU into multiple segments
 *
 * As per 3GPP TS 38.322 Section 4.2.1.2.2 and 4.2.1.3.2
 *
 * @param sdu           Original RLC SDU data
 * @param sdu_length    Length of original SDU
 * @param sn            Sequence number to assign
 * @param max_pdu_size  Maximum PDU size (including header)
 * @param segments      [out] Vector of created segments
 * @param is_am         True for AM mode, False for UM mode
 */
void segment_rlc_sdu(const uint8_t *sdu, size_t sdu_length, uint16_t sn,
                     size_t max_pdu_size, std::vector<RLC_Segment *> &segments,
                     bool is_am = false) {

  std::cout << "\n";
  std::cout
      << "╔═══════════════════════════════════════════════════════════════╗\n";
  std::cout
      << "║  RLC SDU SEGMENTATION PROCESS                                 ║\n";
  std::cout
      << "╚═══════════════════════════════════════════════════════════════╝\n";
  std::cout << "3GPP Reference: TS 38.322 Section 4.2.1.2.2/4.2.1.3.2\n\n";

  std::cout << "[SEGMENTATION INPUT]\n";
  std::cout << "  → Original SDU Length: " << sdu_length << " bytes\n";
  std::cout << "  → Sequence Number (SN): " << sn << "\n";
  std::cout << "  → Max PDU Size: " << max_pdu_size << " bytes\n";
  std::cout << "  → Mode: " << (is_am ? "AM" : "UM") << "\n\n";

  // Calculate header sizes for different segment types
  size_t first_segment_header_size = is_am ? 2 : 2; // No SO field
  size_t other_segment_header_size = is_am ? 4 : 4; // With SO field

  // Calculate available payload sizes
  size_t first_segment_payload = max_pdu_size - first_segment_header_size;
  size_t other_segment_payload = max_pdu_size - other_segment_header_size;

  std::cout << "[HEADER SIZE CALCULATION]\n";
  std::cout << "  → First Segment Header: " << first_segment_header_size
            << " bytes (SI + SN, no SO)\n";
  std::cout << "  → Other Segment Header: " << other_segment_header_size
            << " bytes (SI + SN + SO)\n";
  std::cout << "  → First Segment Payload: " << first_segment_payload
            << " bytes\n";
  std::cout << "  → Other Segment Payload: " << other_segment_payload
            << " bytes\n\n";

  // Check if segmentation is needed
  if (sdu_length + first_segment_header_size <= max_pdu_size) {
    std::cout << "[SEGMENTATION DECISION] No segmentation needed\n";
    std::cout << "  → SDU fits in single PDU\n\n";

    RLC_Segment *segment = new RLC_Segment();
    segment->si = SI_Field::COMPLETE_SDU;
    segment->sn = sn;
    segment->so = 0;
    segment->data_length = sdu_length;
    segment->original_sdu_size = sdu_length;
    segment->data = new uint8_t[sdu_length];
    memcpy(segment->data, sdu, sdu_length);
    segments.push_back(segment);
    return;
  }

  std::cout << "[SEGMENTATION DECISION] Segmentation required\n";
  std::cout << "  → SDU will be split into multiple segments\n\n";

  // Calculate number of segments needed
  size_t remaining = sdu_length;
  size_t offset = 0;
  int segment_count = 0;

  // First segment
  size_t first_chunk = std::min(first_segment_payload, remaining);
  remaining -= first_chunk;
  segment_count++;

  // Calculate remaining segments
  while (remaining > 0) {
    size_t chunk = std::min(other_segment_payload, remaining);
    remaining -= chunk;
    segment_count++;
  }

  std::cout << "[SEGMENT CALCULATION]\n";
  std::cout << "  → Total segments needed: " << segment_count << "\n\n";

  // Create segments
  remaining = sdu_length;
  offset = 0;

  for (int i = 0; i < segment_count; i++) {
    RLC_Segment *segment = new RLC_Segment();
    segment->sn = sn;
    segment->original_sdu_size = sdu_length;

    // Determine SI field and data length
    if (i == 0) {
      // First segment
      segment->si = SI_Field::FIRST_SEGMENT;
      segment->so = 0; // SO not included in first segment
      segment->data_length = std::min(first_segment_payload, remaining);
    } else if (i == segment_count - 1) {
      // Last segment
      segment->si = SI_Field::LAST_SEGMENT;
      segment->so = offset;
      segment->data_length = remaining;
    } else {
      // Middle segment
      segment->si = SI_Field::MIDDLE_SEGMENT;
      segment->so = offset;
      segment->data_length = std::min(other_segment_payload, remaining);
    }

    // Copy data
    segment->data = new uint8_t[segment->data_length];
    memcpy(segment->data, sdu + offset, segment->data_length);

    std::cout
        << "─────────────────────────────────────────────────────────────\n";
    std::cout << "[SEGMENT #" << (i + 1) << "]\n";
    std::cout << "  → SI Field: " << si_field_to_string(segment->si) << "\n";
    std::cout << "  → SN: " << segment->sn << "\n";
    std::cout << "  → SO: " << segment->so << " bytes";
    if (segment->si == SI_Field::FIRST_SEGMENT) {
      std::cout << " (not included in header)";
    }
    std::cout << "\n";
    std::cout << "  → Data Length: " << segment->data_length << " bytes\n";
    std::cout << "  → Byte Range: [" << offset << " - "
              << (offset + segment->data_length - 1) << "]\n";
    std::cout << "  → Header Size: "
              << (segment->si == SI_Field::FIRST_SEGMENT
                      ? first_segment_header_size
                      : other_segment_header_size)
              << " bytes\n";
    std::cout << "  → Total PDU Size: "
              << (segment->data_length + (segment->si == SI_Field::FIRST_SEGMENT
                                              ? first_segment_header_size
                                              : other_segment_header_size))
              << " bytes\n";

    segments.push_back(segment);
    offset += segment->data_length;
    remaining -= segment->data_length;
  }

  std::cout
      << "─────────────────────────────────────────────────────────────\n";
  std::cout << "\n✓ SEGMENTATION COMPLETE\n";
  std::cout << "  → Created " << segment_count
            << " segments from original SDU\n";
  std::cout << "  → Total bytes segmented: " << sdu_length << "\n\n";
}

/**
 * @brief Reassemble RLC SDU from segments
 *
 * As per 3GPP TS 38.322 Section 5.2.2.2.3 and 5.2.3.2.3
 *
 * @param segments      Vector of received segments
 * @param reassembled   [out] Reassembled SDU buffer
 * @return              Length of reassembled SDU, or 0 on failure
 */
size_t reassemble_rlc_sdu(const std::vector<RLC_Segment *> &segments,
                          uint8_t *reassembled) {

  std::cout << "\n";
  std::cout
      << "╔═══════════════════════════════════════════════════════════════╗\n";
  std::cout
      << "║  RLC SDU REASSEMBLY PROCESS                                   ║\n";
  std::cout
      << "╚═══════════════════════════════════════════════════════════════╝\n";
  std::cout << "3GPP Reference: TS 38.322 Section 5.2.2.2.3/5.2.3.2.3\n\n";

  if (segments.empty()) {
    std::cout << "✗ ERROR: No segments to reassemble\n";
    return 0;
  }

  std::cout << "[REASSEMBLY INPUT]\n";
  std::cout << "  → Number of segments: " << segments.size() << "\n";
  std::cout << "  → Sequence Number: " << segments[0]->sn << "\n\n";

  // Check if we have a complete SDU (no segmentation)
  if (segments.size() == 1 && segments[0]->si == SI_Field::COMPLETE_SDU) {
    std::cout << "[REASSEMBLY TYPE] Complete SDU (no segmentation)\n";
    memcpy(reassembled, segments[0]->data, segments[0]->data_length);
    std::cout << "  → SDU Length: " << segments[0]->data_length << " bytes\n";
    std::cout << "\n✓ REASSEMBLY COMPLETE\n\n";
    return segments[0]->data_length;
  }

  std::cout << "[REASSEMBLY TYPE] Segmented SDU reassembly\n\n";

  // Verify we have all segments in order
  std::cout << "[SEGMENT VERIFICATION]\n";
  bool has_first = false, has_last = false;
  for (const auto &seg : segments) {
    std::cout << "  → Segment SI=" << si_field_to_string(seg->si)
              << ", SO=" << seg->so << ", Length=" << seg->data_length << "\n";
    if (seg->si == SI_Field::FIRST_SEGMENT)
      has_first = true;
    if (seg->si == SI_Field::LAST_SEGMENT)
      has_last = true;
  }

  if (!has_first || !has_last) {
    std::cout << "\n✗ ERROR: Missing first or last segment\n";
    return 0;
  }
  std::cout << "  ✓ All required segment types present\n\n";

  // Reassemble in order based on SO field
  std::cout << "[REASSEMBLY PROCESS]\n";
  size_t total_length = 0;

  for (const auto &seg : segments) {
    size_t offset = seg->so;
    std::cout << "  → Copying segment: SO=" << offset
              << ", Length=" << seg->data_length << " bytes\n";
    memcpy(reassembled + offset, seg->data, seg->data_length);
    total_length = std::max(total_length, offset + seg->data_length);
  }

  std::cout << "\n✓ REASSEMBLY COMPLETE\n";
  std::cout << "  → Total reassembled SDU length: " << total_length
            << " bytes\n\n";

  return total_length;
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 5: UMD PDU CONSTRUCTION
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Create UMD PDU from RLC segment
 */
void create_umd_pdu(const RLC_Segment *segment, uint8_t *pdu_buffer,
                    size_t &pdu_length) {

  UMD_PDU_Header header;
  header.si = segment->si;
  header.sn = segment->sn;
  header.so = segment->so;

  // Serialize header
  size_t header_size = header.get_header_size();
  header.serialize(pdu_buffer);

  // Copy data
  memcpy(pdu_buffer + header_size, segment->data, segment->data_length);
  pdu_length = header_size + segment->data_length;

  std::cout << "[UMD PDU CONSTRUCTION]\n";
  std::cout << "  → Header Size: " << header_size << " bytes\n";
  std::cout << "  → Payload Size: " << segment->data_length << " bytes\n";
  std::cout << "  → Total PDU Size: " << pdu_length << " bytes\n";

  // Show header breakdown
  std::cout << "\n  Header Breakdown (byte-by-byte):\n";
  for (size_t i = 0; i < header_size; i++) {
    std::cout << "    Byte " << i << ": 0x" << std::hex << std::setw(2)
              << std::setfill('0') << static_cast<int>(pdu_buffer[i])
              << std::dec << " = ";
    for (int b = 7; b >= 0; b--) {
      std::cout << ((pdu_buffer[i] >> b) & 1);
    }
    std::cout << "b";

    if (i == 0) {
      std::cout << "  [SI=" << static_cast<int>(segment->si)
                << ", SN[11:8]=" << ((pdu_buffer[i] & 0x0F)) << "]";
    } else if (i == 1 && header_size >= 2) {
      std::cout << "  [SN[7:0]=" << static_cast<int>(pdu_buffer[i]) << "]";
    } else if (i == 2 && header_size >= 4) {
      std::cout << "  [SO[15:8]=" << static_cast<int>(pdu_buffer[i]) << "]";
    } else if (i == 3 && header_size >= 4) {
      std::cout << "  [SO[7:0]=" << static_cast<int>(pdu_buffer[i]) << "]";
    }
    std::cout << "\n";
  }
  std::cout << "\n";
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 6: DEMONSTRATION SCENARIOS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Demonstrate SI and SO fields with different scenarios
 */
void demonstrate_segmentation() {

  std::cout << "\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "  5G NR RLC SEGMENTATION DEMONSTRATION\n";
  std::cout << "  SI (Segmentation Information) & SO (Segment Offset) Fields\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "Standard: 3GPP TS 38.322 v19.0.0 Release 19\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n\n";

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 1: Small SDU (No Segmentation)
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 1: Small SDU - No Segmentation Required             "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::string small_message = "Hello 5G!";
  uint8_t *small_sdu = new uint8_t[small_message.length()];
  string_to_bytes(small_message, small_sdu);

  std::cout << "Original SDU: \"" << small_message << "\"\n";
  std::cout << "SDU Length: " << small_message.length() << " bytes\n";
  print_hex("SDU Data", small_sdu, small_message.length());

  std::vector<RLC_Segment *> small_segments;
  segment_rlc_sdu(small_sdu, small_message.length(), 100, 100, small_segments,
                  false);

  // Create UMD PDU
  uint8_t pdu_buffer[200];
  size_t pdu_length;
  create_umd_pdu(small_segments[0], pdu_buffer, pdu_length);
  print_hex("Complete UMD PDU", pdu_buffer, pdu_length);

  // Cleanup
  for (auto seg : small_segments)
    delete seg;
  delete[] small_sdu;

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 2: Large SDU (Requires Segmentation)
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 2: Large SDU - Segmentation Required                "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::string large_message =
      "This is a much longer message that will require segmentation into "
      "multiple RLC PDUs. "
      "The RLC layer will use the SI field to indicate whether each PDU "
      "contains the first, "
      "middle, or last segment. The SO field indicates the byte position of "
      "each segment.";

  uint8_t *large_sdu = new uint8_t[large_message.length()];
  string_to_bytes(large_message, large_sdu);

  std::cout << "Original SDU: \"" << large_message << "\"\n";
  std::cout << "SDU Length: " << large_message.length() << " bytes\n";
  print_hex("SDU Data", large_sdu, large_message.length());

  std::vector<RLC_Segment *> large_segments;
  segment_rlc_sdu(large_sdu, large_message.length(), 200, 60, large_segments,
                  false);

  // Create UMD PDUs for each segment
  std::cout << "\n[PDU CONSTRUCTION FOR ALL SEGMENTS]\n\n";
  std::vector<uint8_t *> pdus;
  std::vector<size_t> pdu_sizes;

  for (size_t i = 0; i < large_segments.size(); i++) {
    std::cout
        << "═════════════════════════════════════════════════════════════\n";
    std::cout << "Segment #" << (i + 1) << " PDU\n";
    std::cout
        << "═════════════════════════════════════════════════════════════\n";

    uint8_t *pdu = new uint8_t[100];
    size_t len;
    create_umd_pdu(large_segments[i], pdu, len);
    print_hex("UMD PDU", pdu, len);

    pdus.push_back(pdu);
    pdu_sizes.push_back(len);
    std::cout << "\n";
  }

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 3: Reassembly
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 3: SDU Reassembly from Segments                     "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n";

  uint8_t *reassembled = new uint8_t[large_message.length()];
  size_t reassembled_length = reassemble_rlc_sdu(large_segments, reassembled);

  std::cout << "[REASSEMBLY VERIFICATION]\n";
  std::cout << "  → Original Length: " << large_message.length() << " bytes\n";
  std::cout << "  → Reassembled Length: " << reassembled_length << " bytes\n";
  print_hex("Reassembled SDU", reassembled, reassembled_length);

  std::string reassembled_str(reinterpret_cast<char *>(reassembled),
                              reassembled_length);
  std::cout << "  → Reassembled Message: \"" << reassembled_str << "\"\n";

  bool match = (reassembled_length == large_message.length()) &&
               (memcmp(large_sdu, reassembled, large_message.length()) == 0);
  std::cout << "\n  Verification: " << (match ? "✓ SUCCESS" : "✗ FAILED")
            << "\n";
  std::cout << "  → Reassembled SDU matches original: "
            << (match ? "YES" : "NO") << "\n\n";

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 4: SI and SO Field Reference Table
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SI FIELD REFERENCE (3GPP TS 38.322 Table 6.2.3.4-1)          "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::cout
      << "  ┌────────┬─────────────────────────────────────────┬──────────┐\n";
  std::cout
      << "  │ Value  │ Description                             │ SO Field │\n";
  std::cout
      << "  ├────────┼─────────────────────────────────────────┼──────────┤\n";
  std::cout
      << "  │  00b   │ Complete RLC SDU (no segmentation)      │    No    │\n";
  std::cout
      << "  │  01b   │ First segment of RLC SDU                │    No    │\n";
  std::cout
      << "  │  10b   │ Last segment of RLC SDU                 │   Yes    │\n";
  std::cout
      << "  │  11b   │ Middle segment of RLC SDU               │   Yes    │\n";
  std::cout
      << "  "
         "└────────┴─────────────────────────────────────────┴──────────┘\n\n";

  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SO FIELD SPECIFICATION (3GPP TS 38.322 Section 6.2.3.5)      "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::cout << "  Length: 16 bits\n";
  std::cout << "  Purpose: Indicates byte position within original RLC SDU\n";
  std::cout << "  Range: 0 - 65535 bytes\n";
  std::cout
      << "  Note: First byte of SDU is position 0 (numbering starts at zero)\n";
  std::cout << "  Special Value: 0xFFFF indicates \"to last byte of SDU\"\n\n";

  // Cleanup
  for (auto seg : large_segments)
    delete seg;
  for (auto pdu : pdus)
    delete[] pdu;
  delete[] large_sdu;
  delete[] reassembled;

  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "  DEMONSTRATION COMPLETE\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n\n";
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 7: MAIN FUNCTION
// ═══════════════════════════════════════════════════════════════════════════

int main() {
  demonstrate_segmentation();
  return 0;
} /**
   * ═══════════════════════════════════════════════════════════════════════════
   * 5G NR RLC SEGMENTATION - SI & SO FIELD DEMONSTRATION
   * ═══════════════════════════════════════════════════════════════════════════
   *
   * Standard Compliance: 3GPP TS 38.322 v19.0.0 (Radio Link Control Protocol)
   *
   * This implementation demonstrates RLC SDU segmentation with:
   *   - Segmentation Information (SI) field (2 bits)
   *   - Segment Offset (SO) field (16 bits)
   *   - Complete segmentation and reassembly procedures
   *
   * Focus Areas:
   *   1. SI Field (TS 38.322 Section 6.2.3.4): Indicates segment type
   *   2. SO Field (TS 38.322 Section 6.2.3.5): Indicates byte position
   *   3. UMD/AMD PDU Construction (Section 6.2.2.3/6.2.2.4)
   *   4. Segmentation Procedures (Section 4.2.1.2/4.2.1.3)
   *
   * Author: 5G RLC Protocol Implementation
   * Date: February 2026
   * ═══════════════════════════════════════════════════════════════════════════
   */

#include <cstdint>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: SEGMENTATION INFORMATION (SI) FIELD DEFINITIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Segmentation Information (SI) field values
 *
 * As per 3GPP TS 38.322 Section 6.2.3.4, Table 6.2.3.4-1
 * Length: 2 bits
 *
 * The SI field indicates whether an RLC PDU contains:
 * - A complete RLC SDU (no segmentation)
 * - The first segment of an RLC SDU
 * - The last segment of an RLC SDU
 * - A middle segment of an RLC SDU
 */
enum class SI_Field : uint8_t {
  COMPLETE_SDU = 0x00, // 00b - Data field contains all bytes of an RLC SDU
  FIRST_SEGMENT =
      0x01, // 01b - Data field contains the first segment of an RLC SDU
  LAST_SEGMENT =
      0x02, // 10b - Data field contains the last segment of an RLC SDU
  MIDDLE_SEGMENT =
      0x03 // 11b - Data field contains neither first nor last segment
};

/**
 * @brief Convert SI field value to string representation
 */
const char *si_field_to_string(SI_Field si) {
  switch (si) {
  case SI_Field::COMPLETE_SDU:
    return "COMPLETE SDU (00b)";
  case SI_Field::FIRST_SEGMENT:
    return "FIRST SEGMENT (01b)";
  case SI_Field::LAST_SEGMENT:
    return "LAST SEGMENT (10b)";
  case SI_Field::MIDDLE_SEGMENT:
    return "MIDDLE SEGMENT (11b)";
  default:
    return "UNKNOWN";
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2: RLC PDU STRUCTURES (3GPP TS 38.322 Section 6.2)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief RLC UMD PDU Header Structure (12-bit SN with SO)
 *
 * As per 3GPP TS 38.322 Section 6.2.2.3, Figure 6.2.2.3-5
 *
 * Byte 0:  SI (2 bits) | R (2 bits) | SN[11:8] (4 bits)
 * Byte 1:  SN[7:0] (8 bits)
 * Byte 2:  SO[15:8] (8 bits)  [Only if segment, not first]
 * Byte 3:  SO[7:0] (8 bits)   [Only if segment, not first]
 */
struct UMD_PDU_Header {
  SI_Field si; // Segmentation Information (2 bits)
  uint16_t sn; // Sequence Number (12 bits for UM)
  uint16_t so; // Segment Offset (16 bits) - present only for segments
  bool has_so; // Indicates if SO field is present

  UMD_PDU_Header() : si(SI_Field::COMPLETE_SDU), sn(0), so(0), has_so(false) {}

  /**
   * @brief Get header size in bytes
   */
  size_t get_header_size() const {
    if (si == SI_Field::COMPLETE_SDU) {
      return 1; // Only SI field (with padding)
    } else if (si == SI_Field::FIRST_SEGMENT) {
      return 2; // SI + SN (no SO for first segment)
    } else {
      return 4; // SI + SN + SO (for middle/last segments)
    }
  }

  /**
   * @brief Serialize header to byte array
   */
  void serialize(uint8_t *buffer) const {
    if (si == SI_Field::COMPLETE_SDU) {
      // TS 38.322 Figure 6.2.2.3-1: UMD PDU containing complete SDU
      buffer[0] = (static_cast<uint8_t>(si) << 6); // SI in bits 7-6
      // Bits 5-0 are reserved (R fields)
    } else if (si == SI_Field::FIRST_SEGMENT) {
      // TS 38.322 Figure 6.2.2.3-3: UMD PDU with 12-bit SN (No SO)
      buffer[0] = (static_cast<uint8_t>(si) << 6) | // SI in bits 7-6
                  ((sn >> 8) & 0x0F);               // SN[11:8] in bits 3-0
      buffer[1] = sn & 0xFF;                        // SN[7:0]
    } else {
      // TS 38.322 Figure 6.2.2.3-5: UMD PDU with 12-bit SN and SO
      buffer[0] = (static_cast<uint8_t>(si) << 6) | // SI in bits 7-6
                  ((sn >> 8) & 0x0F);               // SN[11:8] in bits 3-0
      buffer[1] = sn & 0xFF;                        // SN[7:0]
      buffer[2] = (so >> 8) & 0xFF;                 // SO[15:8]
      buffer[3] = so & 0xFF;                        // SO[7:0]
    }
  }

  /**
   * @brief Deserialize header from byte array
   */
  void deserialize(const uint8_t *buffer) {
    // Extract SI field (bits 7-6 of first byte)
    si = static_cast<SI_Field>((buffer[0] >> 6) & 0x03);

    if (si == SI_Field::COMPLETE_SDU) {
      sn = 0;
      so = 0;
      has_so = false;
    } else if (si == SI_Field::FIRST_SEGMENT) {
      // Extract 12-bit SN
      sn = ((buffer[0] & 0x0F) << 8) | buffer[1];
      so = 0;
      has_so = false;
    } else {
      // Extract 12-bit SN and 16-bit SO
      sn = ((buffer[0] & 0x0F) << 8) | buffer[1];
      so = (buffer[2] << 8) | buffer[3];
      has_so = true;
    }
  }
};

/**
 * @brief RLC AMD PDU Header Structure (12-bit SN with SO)
 *
 * As per 3GPP TS 38.322 Section 6.2.2.4, Figure 6.2.2.4-3
 *
 * Byte 0:  D/C (1 bit) | P (1 bit) | SI (2 bits) | SN[11:8] (4 bits)
 * Byte 1:  SN[7:0] (8 bits)
 * Byte 2:  SO[15:8] (8 bits)  [Only if segment, not first]
 * Byte 3:  SO[7:0] (8 bits)   [Only if segment, not first]
 */
struct AMD_PDU_Header {
  uint8_t dc;  // Data/Control field (1 bit) - always 1 for data
  uint8_t p;   // Polling bit (1 bit)
  SI_Field si; // Segmentation Information (2 bits)
  uint16_t sn; // Sequence Number (12 bits for AM)
  uint16_t so; // Segment Offset (16 bits)
  bool has_so; // Indicates if SO field is present

  AMD_PDU_Header()
      : dc(1), p(0), si(SI_Field::COMPLETE_SDU), sn(0), so(0), has_so(false) {}

  /**
   * @brief Get header size in bytes
   */
  size_t get_header_size() const {
    if (si == SI_Field::COMPLETE_SDU || si == SI_Field::FIRST_SEGMENT) {
      return 2; // D/C + P + SI + SN (no SO)
    } else {
      return 4; // D/C + P + SI + SN + SO
    }
  }

  /**
   * @brief Serialize header to byte array
   */
  void serialize(uint8_t *buffer) const {
    // TS 38.322 Section 6.2.2.4
    buffer[0] = (dc << 7) |                       // D/C bit
                (p << 6) |                        // P bit
                (static_cast<uint8_t>(si) << 4) | // SI field
                ((sn >> 8) & 0x0F);               // SN[11:8]
    buffer[1] = sn & 0xFF;                        // SN[7:0]

    if (si == SI_Field::MIDDLE_SEGMENT || si == SI_Field::LAST_SEGMENT) {
      buffer[2] = (so >> 8) & 0xFF; // SO[15:8]
      buffer[3] = so & 0xFF;        // SO[7:0]
    }
  }

  /**
   * @brief Deserialize header from byte array
   */
  void deserialize(const uint8_t *buffer) {
    dc = (buffer[0] >> 7) & 0x01;
    p = (buffer[0] >> 6) & 0x01;
    si = static_cast<SI_Field>((buffer[0] >> 4) & 0x03);
    sn = ((buffer[0] & 0x0F) << 8) | buffer[1];

    if (si == SI_Field::MIDDLE_SEGMENT || si == SI_Field::LAST_SEGMENT) {
      so = (buffer[2] << 8) | buffer[3];
      has_so = true;
    } else {
      so = 0;
      has_so = false;
    }
  }
};

/**
 * @brief RLC SDU Segment Structure
 */
struct RLC_Segment {
  SI_Field si;              // Segment type
  uint16_t sn;              // Sequence number
  uint16_t so;              // Segment offset (byte position in original SDU)
  uint8_t *data;            // Segment data
  size_t data_length;       // Length of segment data
  size_t original_sdu_size; // Total size of original SDU

  RLC_Segment()
      : si(SI_Field::COMPLETE_SDU), sn(0), so(0), data(nullptr), data_length(0),
        original_sdu_size(0) {}

  ~RLC_Segment() {
    if (data) {
      delete[] data;
    }
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3: UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Print hex dump of byte array
 */
void print_hex(const std::string &label, const uint8_t *data, size_t length) {
  std::cout << label << " (" << length << " bytes):\n  0x";
  for (size_t i = 0; i < length; i++) {
    std::cout << std::hex << std::setw(2) << std::setfill('0')
              << static_cast<int>(data[i]);
    if ((i + 1) % 32 == 0 && i + 1 < length)
      std::cout << "\n  0x";
  }
  std::cout << std::dec << "\n";
}

/**
 * @brief Print binary representation of byte
 */
void print_binary(const std::string &label, uint8_t byte) {
  std::cout << label << ": ";
  for (int i = 7; i >= 0; i--) {
    std::cout << ((byte >> i) & 1);
  }
  std::cout << "b\n";
}

/**
 * @brief Convert string to bytes
 */
void string_to_bytes(const std::string &str, uint8_t *output) {
  for (size_t i = 0; i < str.length(); i++) {
    output[i] = static_cast<uint8_t>(str[i]);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4: RLC SEGMENTATION ENGINE
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Segment an RLC SDU into multiple segments
 *
 * As per 3GPP TS 38.322 Section 4.2.1.2.2 and 4.2.1.3.2
 *
 * @param sdu           Original RLC SDU data
 * @param sdu_length    Length of original SDU
 * @param sn            Sequence number to assign
 * @param max_pdu_size  Maximum PDU size (including header)
 * @param segments      [out] Vector of created segments
 * @param is_am         True for AM mode, False for UM mode
 */
void segment_rlc_sdu(const uint8_t *sdu, size_t sdu_length, uint16_t sn,
                     size_t max_pdu_size, std::vector<RLC_Segment *> &segments,
                     bool is_am = false) {

  std::cout << "\n";
  std::cout
      << "╔═══════════════════════════════════════════════════════════════╗\n";
  std::cout
      << "║  RLC SDU SEGMENTATION PROCESS                                 ║\n";
  std::cout
      << "╚═══════════════════════════════════════════════════════════════╝\n";
  std::cout << "3GPP Reference: TS 38.322 Section 4.2.1.2.2/4.2.1.3.2\n\n";

  std::cout << "[SEGMENTATION INPUT]\n";
  std::cout << "  → Original SDU Length: " << sdu_length << " bytes\n";
  std::cout << "  → Sequence Number (SN): " << sn << "\n";
  std::cout << "  → Max PDU Size: " << max_pdu_size << " bytes\n";
  std::cout << "  → Mode: " << (is_am ? "AM" : "UM") << "\n\n";

  // Calculate header sizes for different segment types
  size_t first_segment_header_size = is_am ? 2 : 2; // No SO field
  size_t other_segment_header_size = is_am ? 4 : 4; // With SO field

  // Calculate available payload sizes
  size_t first_segment_payload = max_pdu_size - first_segment_header_size;
  size_t other_segment_payload = max_pdu_size - other_segment_header_size;

  std::cout << "[HEADER SIZE CALCULATION]\n";
  std::cout << "  → First Segment Header: " << first_segment_header_size
            << " bytes (SI + SN, no SO)\n";
  std::cout << "  → Other Segment Header: " << other_segment_header_size
            << " bytes (SI + SN + SO)\n";
  std::cout << "  → First Segment Payload: " << first_segment_payload
            << " bytes\n";
  std::cout << "  → Other Segment Payload: " << other_segment_payload
            << " bytes\n\n";

  // Check if segmentation is needed
  if (sdu_length + first_segment_header_size <= max_pdu_size) {
    std::cout << "[SEGMENTATION DECISION] No segmentation needed\n";
    std::cout << "  → SDU fits in single PDU\n\n";

    RLC_Segment *segment = new RLC_Segment();
    segment->si = SI_Field::COMPLETE_SDU;
    segment->sn = sn;
    segment->so = 0;
    segment->data_length = sdu_length;
    segment->original_sdu_size = sdu_length;
    segment->data = new uint8_t[sdu_length];
    memcpy(segment->data, sdu, sdu_length);
    segments.push_back(segment);
    return;
  }

  std::cout << "[SEGMENTATION DECISION] Segmentation required\n";
  std::cout << "  → SDU will be split into multiple segments\n\n";

  // Calculate number of segments needed
  size_t remaining = sdu_length;
  size_t offset = 0;
  int segment_count = 0;

  // First segment
  size_t first_chunk = std::min(first_segment_payload, remaining);
  remaining -= first_chunk;
  segment_count++;

  // Calculate remaining segments
  while (remaining > 0) {
    size_t chunk = std::min(other_segment_payload, remaining);
    remaining -= chunk;
    segment_count++;
  }

  std::cout << "[SEGMENT CALCULATION]\n";
  std::cout << "  → Total segments needed: " << segment_count << "\n\n";

  // Create segments
  remaining = sdu_length;
  offset = 0;

  for (int i = 0; i < segment_count; i++) {
    RLC_Segment *segment = new RLC_Segment();
    segment->sn = sn;
    segment->original_sdu_size = sdu_length;

    // Determine SI field and data length
    if (i == 0) {
      // First segment
      segment->si = SI_Field::FIRST_SEGMENT;
      segment->so = 0; // SO not included in first segment
      segment->data_length = std::min(first_segment_payload, remaining);
    } else if (i == segment_count - 1) {
      // Last segment
      segment->si = SI_Field::LAST_SEGMENT;
      segment->so = offset;
      segment->data_length = remaining;
    } else {
      // Middle segment
      segment->si = SI_Field::MIDDLE_SEGMENT;
      segment->so = offset;
      segment->data_length = std::min(other_segment_payload, remaining);
    }

    // Copy data
    segment->data = new uint8_t[segment->data_length];
    memcpy(segment->data, sdu + offset, segment->data_length);

    std::cout
        << "─────────────────────────────────────────────────────────────\n";
    std::cout << "[SEGMENT #" << (i + 1) << "]\n";
    std::cout << "  → SI Field: " << si_field_to_string(segment->si) << "\n";
    std::cout << "  → SN: " << segment->sn << "\n";
    std::cout << "  → SO: " << segment->so << " bytes";
    if (segment->si == SI_Field::FIRST_SEGMENT) {
      std::cout << " (not included in header)";
    }
    std::cout << "\n";
    std::cout << "  → Data Length: " << segment->data_length << " bytes\n";
    std::cout << "  → Byte Range: [" << offset << " - "
              << (offset + segment->data_length - 1) << "]\n";
    std::cout << "  → Header Size: "
              << (segment->si == SI_Field::FIRST_SEGMENT
                      ? first_segment_header_size
                      : other_segment_header_size)
              << " bytes\n";
    std::cout << "  → Total PDU Size: "
              << (segment->data_length + (segment->si == SI_Field::FIRST_SEGMENT
                                              ? first_segment_header_size
                                              : other_segment_header_size))
              << " bytes\n";

    segments.push_back(segment);
    offset += segment->data_length;
    remaining -= segment->data_length;
  }

  std::cout
      << "─────────────────────────────────────────────────────────────\n";
  std::cout << "\n✓ SEGMENTATION COMPLETE\n";
  std::cout << "  → Created " << segment_count
            << " segments from original SDU\n";
  std::cout << "  → Total bytes segmented: " << sdu_length << "\n\n";
}

/**
 * @brief Reassemble RLC SDU from segments
 *
 * As per 3GPP TS 38.322 Section 5.2.2.2.3 and 5.2.3.2.3
 *
 * @param segments      Vector of received segments
 * @param reassembled   [out] Reassembled SDU buffer
 * @return              Length of reassembled SDU, or 0 on failure
 */
size_t reassemble_rlc_sdu(const std::vector<RLC_Segment *> &segments,
                          uint8_t *reassembled) {

  std::cout << "\n";
  std::cout
      << "╔═══════════════════════════════════════════════════════════════╗\n";
  std::cout
      << "║  RLC SDU REASSEMBLY PROCESS                                   ║\n";
  std::cout
      << "╚═══════════════════════════════════════════════════════════════╝\n";
  std::cout << "3GPP Reference: TS 38.322 Section 5.2.2.2.3/5.2.3.2.3\n\n";

  if (segments.empty()) {
    std::cout << "✗ ERROR: No segments to reassemble\n";
    return 0;
  }

  std::cout << "[REASSEMBLY INPUT]\n";
  std::cout << "  → Number of segments: " << segments.size() << "\n";
  std::cout << "  → Sequence Number: " << segments[0]->sn << "\n\n";

  // Check if we have a complete SDU (no segmentation)
  if (segments.size() == 1 && segments[0]->si == SI_Field::COMPLETE_SDU) {
    std::cout << "[REASSEMBLY TYPE] Complete SDU (no segmentation)\n";
    memcpy(reassembled, segments[0]->data, segments[0]->data_length);
    std::cout << "  → SDU Length: " << segments[0]->data_length << " bytes\n";
    std::cout << "\n✓ REASSEMBLY COMPLETE\n\n";
    return segments[0]->data_length;
  }

  std::cout << "[REASSEMBLY TYPE] Segmented SDU reassembly\n\n";

  // Verify we have all segments in order
  std::cout << "[SEGMENT VERIFICATION]\n";
  bool has_first = false, has_last = false;
  for (const auto &seg : segments) {
    std::cout << "  → Segment SI=" << si_field_to_string(seg->si)
              << ", SO=" << seg->so << ", Length=" << seg->data_length << "\n";
    if (seg->si == SI_Field::FIRST_SEGMENT)
      has_first = true;
    if (seg->si == SI_Field::LAST_SEGMENT)
      has_last = true;
  }

  if (!has_first || !has_last) {
    std::cout << "\n✗ ERROR: Missing first or last segment\n";
    return 0;
  }
  std::cout << "  ✓ All required segment types present\n\n";

  // Reassemble in order based on SO field
  std::cout << "[REASSEMBLY PROCESS]\n";
  size_t total_length = 0;

  for (const auto &seg : segments) {
    size_t offset = seg->so;
    std::cout << "  → Copying segment: SO=" << offset
              << ", Length=" << seg->data_length << " bytes\n";
    memcpy(reassembled + offset, seg->data, seg->data_length);
    total_length = std::max(total_length, offset + seg->data_length);
  }

  std::cout << "\n✓ REASSEMBLY COMPLETE\n";
  std::cout << "  → Total reassembled SDU length: " << total_length
            << " bytes\n\n";

  return total_length;
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 5: UMD PDU CONSTRUCTION
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Create UMD PDU from RLC segment
 */
void create_umd_pdu(const RLC_Segment *segment, uint8_t *pdu_buffer,
                    size_t &pdu_length) {

  UMD_PDU_Header header;
  header.si = segment->si;
  header.sn = segment->sn;
  header.so = segment->so;

  // Serialize header
  size_t header_size = header.get_header_size();
  header.serialize(pdu_buffer);

  // Copy data
  memcpy(pdu_buffer + header_size, segment->data, segment->data_length);
  pdu_length = header_size + segment->data_length;

  std::cout << "[UMD PDU CONSTRUCTION]\n";
  std::cout << "  → Header Size: " << header_size << " bytes\n";
  std::cout << "  → Payload Size: " << segment->data_length << " bytes\n";
  std::cout << "  → Total PDU Size: " << pdu_length << " bytes\n";

  // Show header breakdown
  std::cout << "\n  Header Breakdown (byte-by-byte):\n";
  for (size_t i = 0; i < header_size; i++) {
    std::cout << "    Byte " << i << ": 0x" << std::hex << std::setw(2)
              << std::setfill('0') << static_cast<int>(pdu_buffer[i])
              << std::dec << " = ";
    for (int b = 7; b >= 0; b--) {
      std::cout << ((pdu_buffer[i] >> b) & 1);
    }
    std::cout << "b";

    if (i == 0) {
      std::cout << "  [SI=" << static_cast<int>(segment->si)
                << ", SN[11:8]=" << ((pdu_buffer[i] & 0x0F)) << "]";
    } else if (i == 1 && header_size >= 2) {
      std::cout << "  [SN[7:0]=" << static_cast<int>(pdu_buffer[i]) << "]";
    } else if (i == 2 && header_size >= 4) {
      std::cout << "  [SO[15:8]=" << static_cast<int>(pdu_buffer[i]) << "]";
    } else if (i == 3 && header_size >= 4) {
      std::cout << "  [SO[7:0]=" << static_cast<int>(pdu_buffer[i]) << "]";
    }
    std::cout << "\n";
  }
  std::cout << "\n";
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 6: DEMONSTRATION SCENARIOS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Demonstrate SI and SO fields with different scenarios
 */
void demonstrate_segmentation() {

  std::cout << "\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "  5G NR RLC SEGMENTATION DEMONSTRATION\n";
  std::cout << "  SI (Segmentation Information) & SO (Segment Offset) Fields\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "Standard: 3GPP TS 38.322 v19.0.0 Release 19\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n\n";

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 1: Small SDU (No Segmentation)
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 1: Small SDU - No Segmentation Required             "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::string small_message = "Hello 5G!";
  uint8_t *small_sdu = new uint8_t[small_message.length()];
  string_to_bytes(small_message, small_sdu);

  std::cout << "Original SDU: \"" << small_message << "\"\n";
  std::cout << "SDU Length: " << small_message.length() << " bytes\n";
  print_hex("SDU Data", small_sdu, small_message.length());

  std::vector<RLC_Segment *> small_segments;
  segment_rlc_sdu(small_sdu, small_message.length(), 100, 100, small_segments,
                  false);

  // Create UMD PDU
  uint8_t pdu_buffer[200];
  size_t pdu_length;
  create_umd_pdu(small_segments[0], pdu_buffer, pdu_length);
  print_hex("Complete UMD PDU", pdu_buffer, pdu_length);

  // Cleanup
  for (auto seg : small_segments)
    delete seg;
  delete[] small_sdu;

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 2: Large SDU (Requires Segmentation)
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 2: Large SDU - Segmentation Required                "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::string large_message =
      "This is a much longer message that will require segmentation into "
      "multiple RLC PDUs. "
      "The RLC layer will use the SI field to indicate whether each PDU "
      "contains the first, "
      "middle, or last segment. The SO field indicates the byte position of "
      "each segment.";

  uint8_t *large_sdu = new uint8_t[large_message.length()];
  string_to_bytes(large_message, large_sdu);

  std::cout << "Original SDU: \"" << large_message << "\"\n";
  std::cout << "SDU Length: " << large_message.length() << " bytes\n";
  print_hex("SDU Data", large_sdu, large_message.length());

  std::vector<RLC_Segment *> large_segments;
  segment_rlc_sdu(large_sdu, large_message.length(), 200, 60, large_segments,
                  false);

  // Create UMD PDUs for each segment
  std::cout << "\n[PDU CONSTRUCTION FOR ALL SEGMENTS]\n\n";
  std::vector<uint8_t *> pdus;
  std::vector<size_t> pdu_sizes;

  for (size_t i = 0; i < large_segments.size(); i++) {
    std::cout
        << "═════════════════════════════════════════════════════════════\n";
    std::cout << "Segment #" << (i + 1) << " PDU\n";
    std::cout
        << "═════════════════════════════════════════════════════════════\n";

    uint8_t *pdu = new uint8_t[100];
    size_t len;
    create_umd_pdu(large_segments[i], pdu, len);
    print_hex("UMD PDU", pdu, len);

    pdus.push_back(pdu);
    pdu_sizes.push_back(len);
    std::cout << "\n";
  }

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 3: Reassembly
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 3: SDU Reassembly from Segments                     "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n";

  uint8_t *reassembled = new uint8_t[large_message.length()];
  size_t reassembled_length = reassemble_rlc_sdu(large_segments, reassembled);

  std::cout << "[REASSEMBLY VERIFICATION]\n";
  std::cout << "  → Original Length: " << large_message.length() << " bytes\n";
  std::cout << "  → Reassembled Length: " << reassembled_length << " bytes\n";
  print_hex("Reassembled SDU", reassembled, reassembled_length);

  std::string reassembled_str(reinterpret_cast<char *>(reassembled),
                              reassembled_length);
  std::cout << "  → Reassembled Message: \"" << reassembled_str << "\"\n";

  bool match = (reassembled_length == large_message.length()) &&
               (memcmp(large_sdu, reassembled, large_message.length()) == 0);
  std::cout << "\n  Verification: " << (match ? "✓ SUCCESS" : "✗ FAILED")
            << "\n";
  std::cout << "  → Reassembled SDU matches original: "
            << (match ? "YES" : "NO") << "\n\n";

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 4: SI and SO Field Reference Table
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SI FIELD REFERENCE (3GPP TS 38.322 Table 6.2.3.4-1)          "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::cout
      << "  ┌────────┬─────────────────────────────────────────┬──────────┐\n";
  std::cout
      << "  │ Value  │ Description                             │ SO Field │\n";
  std::cout
      << "  ├────────┼─────────────────────────────────────────┼──────────┤\n";
  std::cout
      << "  │  00b   │ Complete RLC SDU (no segmentation)      │    No    │\n";
  std::cout
      << "  │  01b   │ First segment of RLC SDU                │    No    │\n";
  std::cout
      << "  │  10b   │ Last segment of RLC SDU                 │   Yes    │\n";
  std::cout
      << "  │  11b   │ Middle segment of RLC SDU               │   Yes    │\n";
  std::cout
      << "  "
         "└────────┴─────────────────────────────────────────┴──────────┘\n\n";

  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SO FIELD SPECIFICATION (3GPP TS 38.322 Section 6.2.3.5)      "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::cout << "  Length: 16 bits\n";
  std::cout << "  Purpose: Indicates byte position within original RLC SDU\n";
  std::cout << "  Range: 0 - 65535 bytes\n";
  std::cout
      << "  Note: First byte of SDU is position 0 (numbering starts at zero)\n";
  std::cout << "  Special Value: 0xFFFF indicates \"to last byte of SDU\"\n\n";

  // Cleanup
  for (auto seg : large_segments)
    delete seg;
  for (auto pdu : pdus)
    delete[] pdu;
  delete[] large_sdu;
  delete[] reassembled;

  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "  DEMONSTRATION COMPLETE\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n\n";
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 7: MAIN FUNCTION
// ═══════════════════════════════════════════════════════════════════════════

int main() {
  demonstrate_segmentation();
  return 0;
} /**
   * ═══════════════════════════════════════════════════════════════════════════
   * 5G NR RLC SEGMENTATION - SI & SO FIELD DEMONSTRATION
   * ═══════════════════════════════════════════════════════════════════════════
   *
   * Standard Compliance: 3GPP TS 38.322 v19.0.0 (Radio Link Control Protocol)
   *
   * This implementation demonstrates RLC SDU segmentation with:
   *   - Segmentation Information (SI) field (2 bits)
   *   - Segment Offset (SO) field (16 bits)
   *   - Complete segmentation and reassembly procedures
   *
   * Focus Areas:
   *   1. SI Field (TS 38.322 Section 6.2.3.4): Indicates segment type
   *   2. SO Field (TS 38.322 Section 6.2.3.5): Indicates byte position
   *   3. UMD/AMD PDU Construction (Section 6.2.2.3/6.2.2.4)
   *   4. Segmentation Procedures (Section 4.2.1.2/4.2.1.3)
   *
   * Author: 5G RLC Protocol Implementation
   * Date: February 2026
   * ═══════════════════════════════════════════════════════════════════════════
   */

#include <cstdint>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: SEGMENTATION INFORMATION (SI) FIELD DEFINITIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Segmentation Information (SI) field values
 *
 * As per 3GPP TS 38.322 Section 6.2.3.4, Table 6.2.3.4-1
 * Length: 2 bits
 *
 * The SI field indicates whether an RLC PDU contains:
 * - A complete RLC SDU (no segmentation)
 * - The first segment of an RLC SDU
 * - The last segment of an RLC SDU
 * - A middle segment of an RLC SDU
 */
enum class SI_Field : uint8_t {
  COMPLETE_SDU = 0x00, // 00b - Data field contains all bytes of an RLC SDU
  FIRST_SEGMENT =
      0x01, // 01b - Data field contains the first segment of an RLC SDU
  LAST_SEGMENT =
      0x02, // 10b - Data field contains the last segment of an RLC SDU
  MIDDLE_SEGMENT =
      0x03 // 11b - Data field contains neither first nor last segment
};

/**
 * @brief Convert SI field value to string representation
 */
const char *si_field_to_string(SI_Field si) {
  switch (si) {
  case SI_Field::COMPLETE_SDU:
    return "COMPLETE SDU (00b)";
  case SI_Field::FIRST_SEGMENT:
    return "FIRST SEGMENT (01b)";
  case SI_Field::LAST_SEGMENT:
    return "LAST SEGMENT (10b)";
  case SI_Field::MIDDLE_SEGMENT:
    return "MIDDLE SEGMENT (11b)";
  default:
    return "UNKNOWN";
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2: RLC PDU STRUCTURES (3GPP TS 38.322 Section 6.2)
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief RLC UMD PDU Header Structure (12-bit SN with SO)
 *
 * As per 3GPP TS 38.322 Section 6.2.2.3, Figure 6.2.2.3-5
 *
 * Byte 0:  SI (2 bits) | R (2 bits) | SN[11:8] (4 bits)
 * Byte 1:  SN[7:0] (8 bits)
 * Byte 2:  SO[15:8] (8 bits)  [Only if segment, not first]
 * Byte 3:  SO[7:0] (8 bits)   [Only if segment, not first]
 */
struct UMD_PDU_Header {
  SI_Field si; // Segmentation Information (2 bits)
  uint16_t sn; // Sequence Number (12 bits for UM)
  uint16_t so; // Segment Offset (16 bits) - present only for segments
  bool has_so; // Indicates if SO field is present

  UMD_PDU_Header() : si(SI_Field::COMPLETE_SDU), sn(0), so(0), has_so(false) {}

  /**
   * @brief Get header size in bytes
   */
  size_t get_header_size() const {
    if (si == SI_Field::COMPLETE_SDU) {
      return 1; // Only SI field (with padding)
    } else if (si == SI_Field::FIRST_SEGMENT) {
      return 2; // SI + SN (no SO for first segment)
    } else {
      return 4; // SI + SN + SO (for middle/last segments)
    }
  }

  /**
   * @brief Serialize header to byte array
   */
  void serialize(uint8_t *buffer) const {
    if (si == SI_Field::COMPLETE_SDU) {
      // TS 38.322 Figure 6.2.2.3-1: UMD PDU containing complete SDU
      buffer[0] = (static_cast<uint8_t>(si) << 6); // SI in bits 7-6
      // Bits 5-0 are reserved (R fields)
    } else if (si == SI_Field::FIRST_SEGMENT) {
      // TS 38.322 Figure 6.2.2.3-3: UMD PDU with 12-bit SN (No SO)
      buffer[0] = (static_cast<uint8_t>(si) << 6) | // SI in bits 7-6
                  ((sn >> 8) & 0x0F);               // SN[11:8] in bits 3-0
      buffer[1] = sn & 0xFF;                        // SN[7:0]
    } else {
      // TS 38.322 Figure 6.2.2.3-5: UMD PDU with 12-bit SN and SO
      buffer[0] = (static_cast<uint8_t>(si) << 6) | // SI in bits 7-6
                  ((sn >> 8) & 0x0F);               // SN[11:8] in bits 3-0
      buffer[1] = sn & 0xFF;                        // SN[7:0]
      buffer[2] = (so >> 8) & 0xFF;                 // SO[15:8]
      buffer[3] = so & 0xFF;                        // SO[7:0]
    }
  }

  /**
   * @brief Deserialize header from byte array
   */
  void deserialize(const uint8_t *buffer) {
    // Extract SI field (bits 7-6 of first byte)
    si = static_cast<SI_Field>((buffer[0] >> 6) & 0x03);

    if (si == SI_Field::COMPLETE_SDU) {
      sn = 0;
      so = 0;
      has_so = false;
    } else if (si == SI_Field::FIRST_SEGMENT) {
      // Extract 12-bit SN
      sn = ((buffer[0] & 0x0F) << 8) | buffer[1];
      so = 0;
      has_so = false;
    } else {
      // Extract 12-bit SN and 16-bit SO
      sn = ((buffer[0] & 0x0F) << 8) | buffer[1];
      so = (buffer[2] << 8) | buffer[3];
      has_so = true;
    }
  }
};

/**
 * @brief RLC AMD PDU Header Structure (12-bit SN with SO)
 *
 * As per 3GPP TS 38.322 Section 6.2.2.4, Figure 6.2.2.4-3
 *
 * Byte 0:  D/C (1 bit) | P (1 bit) | SI (2 bits) | SN[11:8] (4 bits)
 * Byte 1:  SN[7:0] (8 bits)
 * Byte 2:  SO[15:8] (8 bits)  [Only if segment, not first]
 * Byte 3:  SO[7:0] (8 bits)   [Only if segment, not first]
 */
struct AMD_PDU_Header {
  uint8_t dc;  // Data/Control field (1 bit) - always 1 for data
  uint8_t p;   // Polling bit (1 bit)
  SI_Field si; // Segmentation Information (2 bits)
  uint16_t sn; // Sequence Number (12 bits for AM)
  uint16_t so; // Segment Offset (16 bits)
  bool has_so; // Indicates if SO field is present

  AMD_PDU_Header()
      : dc(1), p(0), si(SI_Field::COMPLETE_SDU), sn(0), so(0), has_so(false) {}

  /**
   * @brief Get header size in bytes
   */
  size_t get_header_size() const {
    if (si == SI_Field::COMPLETE_SDU || si == SI_Field::FIRST_SEGMENT) {
      return 2; // D/C + P + SI + SN (no SO)
    } else {
      return 4; // D/C + P + SI + SN + SO
    }
  }

  /**
   * @brief Serialize header to byte array
   */
  void serialize(uint8_t *buffer) const {
    // TS 38.322 Section 6.2.2.4
    buffer[0] = (dc << 7) |                       // D/C bit
                (p << 6) |                        // P bit
                (static_cast<uint8_t>(si) << 4) | // SI field
                ((sn >> 8) & 0x0F);               // SN[11:8]
    buffer[1] = sn & 0xFF;                        // SN[7:0]

    if (si == SI_Field::MIDDLE_SEGMENT || si == SI_Field::LAST_SEGMENT) {
      buffer[2] = (so >> 8) & 0xFF; // SO[15:8]
      buffer[3] = so & 0xFF;        // SO[7:0]
    }
  }

  /**
   * @brief Deserialize header from byte array
   */
  void deserialize(const uint8_t *buffer) {
    dc = (buffer[0] >> 7) & 0x01;
    p = (buffer[0] >> 6) & 0x01;
    si = static_cast<SI_Field>((buffer[0] >> 4) & 0x03);
    sn = ((buffer[0] & 0x0F) << 8) | buffer[1];

    if (si == SI_Field::MIDDLE_SEGMENT || si == SI_Field::LAST_SEGMENT) {
      so = (buffer[2] << 8) | buffer[3];
      has_so = true;
    } else {
      so = 0;
      has_so = false;
    }
  }
};

/**
 * @brief RLC SDU Segment Structure
 */
struct RLC_Segment {
  SI_Field si;              // Segment type
  uint16_t sn;              // Sequence number
  uint16_t so;              // Segment offset (byte position in original SDU)
  uint8_t *data;            // Segment data
  size_t data_length;       // Length of segment data
  size_t original_sdu_size; // Total size of original SDU

  RLC_Segment()
      : si(SI_Field::COMPLETE_SDU), sn(0), so(0), data(nullptr), data_length(0),
        original_sdu_size(0) {}

  ~RLC_Segment() {
    if (data) {
      delete[] data;
    }
  }
};

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3: UTILITY FUNCTIONS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Print hex dump of byte array
 */
void print_hex(const std::string &label, const uint8_t *data, size_t length) {
  std::cout << label << " (" << length << " bytes):\n  0x";
  for (size_t i = 0; i < length; i++) {
    std::cout << std::hex << std::setw(2) << std::setfill('0')
              << static_cast<int>(data[i]);
    if ((i + 1) % 32 == 0 && i + 1 < length)
      std::cout << "\n  0x";
  }
  std::cout << std::dec << "\n";
}

/**
 * @brief Print binary representation of byte
 */
void print_binary(const std::string &label, uint8_t byte) {
  std::cout << label << ": ";
  for (int i = 7; i >= 0; i--) {
    std::cout << ((byte >> i) & 1);
  }
  std::cout << "b\n";
}

/**
 * @brief Convert string to bytes
 */
void string_to_bytes(const std::string &str, uint8_t *output) {
  for (size_t i = 0; i < str.length(); i++) {
    output[i] = static_cast<uint8_t>(str[i]);
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4: RLC SEGMENTATION ENGINE
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Segment an RLC SDU into multiple segments
 *
 * As per 3GPP TS 38.322 Section 4.2.1.2.2 and 4.2.1.3.2
 *
 * @param sdu           Original RLC SDU data
 * @param sdu_length    Length of original SDU
 * @param sn            Sequence number to assign
 * @param max_pdu_size  Maximum PDU size (including header)
 * @param segments      [out] Vector of created segments
 * @param is_am         True for AM mode, False for UM mode
 */
void segment_rlc_sdu(const uint8_t *sdu, size_t sdu_length, uint16_t sn,
                     size_t max_pdu_size, std::vector<RLC_Segment *> &segments,
                     bool is_am = false) {

  std::cout << "\n";
  std::cout
      << "╔═══════════════════════════════════════════════════════════════╗\n";
  std::cout
      << "║  RLC SDU SEGMENTATION PROCESS                                 ║\n";
  std::cout
      << "╚═══════════════════════════════════════════════════════════════╝\n";
  std::cout << "3GPP Reference: TS 38.322 Section 4.2.1.2.2/4.2.1.3.2\n\n";

  std::cout << "[SEGMENTATION INPUT]\n";
  std::cout << "  → Original SDU Length: " << sdu_length << " bytes\n";
  std::cout << "  → Sequence Number (SN): " << sn << "\n";
  std::cout << "  → Max PDU Size: " << max_pdu_size << " bytes\n";
  std::cout << "  → Mode: " << (is_am ? "AM" : "UM") << "\n\n";

  // Calculate header sizes for different segment types
  size_t first_segment_header_size = is_am ? 2 : 2; // No SO field
  size_t other_segment_header_size = is_am ? 4 : 4; // With SO field

  // Calculate available payload sizes
  size_t first_segment_payload = max_pdu_size - first_segment_header_size;
  size_t other_segment_payload = max_pdu_size - other_segment_header_size;

  std::cout << "[HEADER SIZE CALCULATION]\n";
  std::cout << "  → First Segment Header: " << first_segment_header_size
            << " bytes (SI + SN, no SO)\n";
  std::cout << "  → Other Segment Header: " << other_segment_header_size
            << " bytes (SI + SN + SO)\n";
  std::cout << "  → First Segment Payload: " << first_segment_payload
            << " bytes\n";
  std::cout << "  → Other Segment Payload: " << other_segment_payload
            << " bytes\n\n";

  // Check if segmentation is needed
  if (sdu_length + first_segment_header_size <= max_pdu_size) {
    std::cout << "[SEGMENTATION DECISION] No segmentation needed\n";
    std::cout << "  → SDU fits in single PDU\n\n";

    RLC_Segment *segment = new RLC_Segment();
    segment->si = SI_Field::COMPLETE_SDU;
    segment->sn = sn;
    segment->so = 0;
    segment->data_length = sdu_length;
    segment->original_sdu_size = sdu_length;
    segment->data = new uint8_t[sdu_length];
    memcpy(segment->data, sdu, sdu_length);
    segments.push_back(segment);
    return;
  }

  std::cout << "[SEGMENTATION DECISION] Segmentation required\n";
  std::cout << "  → SDU will be split into multiple segments\n\n";

  // Calculate number of segments needed
  size_t remaining = sdu_length;
  size_t offset = 0;
  int segment_count = 0;

  // First segment
  size_t first_chunk = std::min(first_segment_payload, remaining);
  remaining -= first_chunk;
  segment_count++;

  // Calculate remaining segments
  while (remaining > 0) {
    size_t chunk = std::min(other_segment_payload, remaining);
    remaining -= chunk;
    segment_count++;
  }

  std::cout << "[SEGMENT CALCULATION]\n";
  std::cout << "  → Total segments needed: " << segment_count << "\n\n";

  // Create segments
  remaining = sdu_length;
  offset = 0;

  for (int i = 0; i < segment_count; i++) {
    RLC_Segment *segment = new RLC_Segment();
    segment->sn = sn;
    segment->original_sdu_size = sdu_length;

    // Determine SI field and data length
    if (i == 0) {
      // First segment
      segment->si = SI_Field::FIRST_SEGMENT;
      segment->so = 0; // SO not included in first segment
      segment->data_length = std::min(first_segment_payload, remaining);
    } else if (i == segment_count - 1) {
      // Last segment
      segment->si = SI_Field::LAST_SEGMENT;
      segment->so = offset;
      segment->data_length = remaining;
    } else {
      // Middle segment
      segment->si = SI_Field::MIDDLE_SEGMENT;
      segment->so = offset;
      segment->data_length = std::min(other_segment_payload, remaining);
    }

    // Copy data
    segment->data = new uint8_t[segment->data_length];
    memcpy(segment->data, sdu + offset, segment->data_length);

    std::cout
        << "─────────────────────────────────────────────────────────────\n";
    std::cout << "[SEGMENT #" << (i + 1) << "]\n";
    std::cout << "  → SI Field: " << si_field_to_string(segment->si) << "\n";
    std::cout << "  → SN: " << segment->sn << "\n";
    std::cout << "  → SO: " << segment->so << " bytes";
    if (segment->si == SI_Field::FIRST_SEGMENT) {
      std::cout << " (not included in header)";
    }
    std::cout << "\n";
    std::cout << "  → Data Length: " << segment->data_length << " bytes\n";
    std::cout << "  → Byte Range: [" << offset << " - "
              << (offset + segment->data_length - 1) << "]\n";
    std::cout << "  → Header Size: "
              << (segment->si == SI_Field::FIRST_SEGMENT
                      ? first_segment_header_size
                      : other_segment_header_size)
              << " bytes\n";
    std::cout << "  → Total PDU Size: "
              << (segment->data_length + (segment->si == SI_Field::FIRST_SEGMENT
                                              ? first_segment_header_size
                                              : other_segment_header_size))
              << " bytes\n";

    segments.push_back(segment);
    offset += segment->data_length;
    remaining -= segment->data_length;
  }

  std::cout
      << "─────────────────────────────────────────────────────────────\n";
  std::cout << "\n✓ SEGMENTATION COMPLETE\n";
  std::cout << "  → Created " << segment_count
            << " segments from original SDU\n";
  std::cout << "  → Total bytes segmented: " << sdu_length << "\n\n";
}

/**
 * @brief Reassemble RLC SDU from segments
 *
 * As per 3GPP TS 38.322 Section 5.2.2.2.3 and 5.2.3.2.3
 *
 * @param segments      Vector of received segments
 * @param reassembled   [out] Reassembled SDU buffer
 * @return              Length of reassembled SDU, or 0 on failure
 */
size_t reassemble_rlc_sdu(const std::vector<RLC_Segment *> &segments,
                          uint8_t *reassembled) {

  std::cout << "\n";
  std::cout
      << "╔═══════════════════════════════════════════════════════════════╗\n";
  std::cout
      << "║  RLC SDU REASSEMBLY PROCESS                                   ║\n";
  std::cout
      << "╚═══════════════════════════════════════════════════════════════╝\n";
  std::cout << "3GPP Reference: TS 38.322 Section 5.2.2.2.3/5.2.3.2.3\n\n";

  if (segments.empty()) {
    std::cout << "✗ ERROR: No segments to reassemble\n";
    return 0;
  }

  std::cout << "[REASSEMBLY INPUT]\n";
  std::cout << "  → Number of segments: " << segments.size() << "\n";
  std::cout << "  → Sequence Number: " << segments[0]->sn << "\n\n";

  // Check if we have a complete SDU (no segmentation)
  if (segments.size() == 1 && segments[0]->si == SI_Field::COMPLETE_SDU) {
    std::cout << "[REASSEMBLY TYPE] Complete SDU (no segmentation)\n";
    memcpy(reassembled, segments[0]->data, segments[0]->data_length);
    std::cout << "  → SDU Length: " << segments[0]->data_length << " bytes\n";
    std::cout << "\n✓ REASSEMBLY COMPLETE\n\n";
    return segments[0]->data_length;
  }

  std::cout << "[REASSEMBLY TYPE] Segmented SDU reassembly\n\n";

  // Verify we have all segments in order
  std::cout << "[SEGMENT VERIFICATION]\n";
  bool has_first = false, has_last = false;
  for (const auto &seg : segments) {
    std::cout << "  → Segment SI=" << si_field_to_string(seg->si)
              << ", SO=" << seg->so << ", Length=" << seg->data_length << "\n";
    if (seg->si == SI_Field::FIRST_SEGMENT)
      has_first = true;
    if (seg->si == SI_Field::LAST_SEGMENT)
      has_last = true;
  }

  if (!has_first || !has_last) {
    std::cout << "\n✗ ERROR: Missing first or last segment\n";
    return 0;
  }
  std::cout << "  ✓ All required segment types present\n\n";

  // Reassemble in order based on SO field
  std::cout << "[REASSEMBLY PROCESS]\n";
  size_t total_length = 0;

  for (const auto &seg : segments) {
    size_t offset = seg->so;
    std::cout << "  → Copying segment: SO=" << offset
              << ", Length=" << seg->data_length << " bytes\n";
    memcpy(reassembled + offset, seg->data, seg->data_length);
    total_length = std::max(total_length, offset + seg->data_length);
  }

  std::cout << "\n✓ REASSEMBLY COMPLETE\n";
  std::cout << "  → Total reassembled SDU length: " << total_length
            << " bytes\n\n";

  return total_length;
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 5: UMD PDU CONSTRUCTION
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Create UMD PDU from RLC segment
 */
void create_umd_pdu(const RLC_Segment *segment, uint8_t *pdu_buffer,
                    size_t &pdu_length) {

  UMD_PDU_Header header;
  header.si = segment->si;
  header.sn = segment->sn;
  header.so = segment->so;

  // Serialize header
  size_t header_size = header.get_header_size();
  header.serialize(pdu_buffer);

  // Copy data
  memcpy(pdu_buffer + header_size, segment->data, segment->data_length);
  pdu_length = header_size + segment->data_length;

  std::cout << "[UMD PDU CONSTRUCTION]\n";
  std::cout << "  → Header Size: " << header_size << " bytes\n";
  std::cout << "  → Payload Size: " << segment->data_length << " bytes\n";
  std::cout << "  → Total PDU Size: " << pdu_length << " bytes\n";

  // Show header breakdown
  std::cout << "\n  Header Breakdown (byte-by-byte):\n";
  for (size_t i = 0; i < header_size; i++) {
    std::cout << "    Byte " << i << ": 0x" << std::hex << std::setw(2)
              << std::setfill('0') << static_cast<int>(pdu_buffer[i])
              << std::dec << " = ";
    for (int b = 7; b >= 0; b--) {
      std::cout << ((pdu_buffer[i] >> b) & 1);
    }
    std::cout << "b";

    if (i == 0) {
      std::cout << "  [SI=" << static_cast<int>(segment->si)
                << ", SN[11:8]=" << ((pdu_buffer[i] & 0x0F)) << "]";
    } else if (i == 1 && header_size >= 2) {
      std::cout << "  [SN[7:0]=" << static_cast<int>(pdu_buffer[i]) << "]";
    } else if (i == 2 && header_size >= 4) {
      std::cout << "  [SO[15:8]=" << static_cast<int>(pdu_buffer[i]) << "]";
    } else if (i == 3 && header_size >= 4) {
      std::cout << "  [SO[7:0]=" << static_cast<int>(pdu_buffer[i]) << "]";
    }
    std::cout << "\n";
  }
  std::cout << "\n";
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 6: DEMONSTRATION SCENARIOS
// ═══════════════════════════════════════════════════════════════════════════

/**
 * @brief Demonstrate SI and SO fields with different scenarios
 */
void demonstrate_segmentation() {

  std::cout << "\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "  5G NR RLC SEGMENTATION DEMONSTRATION\n";
  std::cout << "  SI (Segmentation Information) & SO (Segment Offset) Fields\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "Standard: 3GPP TS 38.322 v19.0.0 Release 19\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n\n";

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 1: Small SDU (No Segmentation)
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 1: Small SDU - No Segmentation Required             "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::string small_message = "Hello 5G!";
  uint8_t *small_sdu = new uint8_t[small_message.length()];
  string_to_bytes(small_message, small_sdu);

  std::cout << "Original SDU: \"" << small_message << "\"\n";
  std::cout << "SDU Length: " << small_message.length() << " bytes\n";
  print_hex("SDU Data", small_sdu, small_message.length());

  std::vector<RLC_Segment *> small_segments;
  segment_rlc_sdu(small_sdu, small_message.length(), 100, 100, small_segments,
                  false);

  // Create UMD PDU
  uint8_t pdu_buffer[200];
  size_t pdu_length;
  create_umd_pdu(small_segments[0], pdu_buffer, pdu_length);
  print_hex("Complete UMD PDU", pdu_buffer, pdu_length);

  // Cleanup
  for (auto seg : small_segments)
    delete seg;
  delete[] small_sdu;

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 2: Large SDU (Requires Segmentation)
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 2: Large SDU - Segmentation Required                "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::string large_message =
      "This is a much longer message that will require segmentation into "
      "multiple RLC PDUs. "
      "The RLC layer will use the SI field to indicate whether each PDU "
      "contains the first, "
      "middle, or last segment. The SO field indicates the byte position of "
      "each segment.";

  uint8_t *large_sdu = new uint8_t[large_message.length()];
  string_to_bytes(large_message, large_sdu);

  std::cout << "Original SDU: \"" << large_message << "\"\n";
  std::cout << "SDU Length: " << large_message.length() << " bytes\n";
  print_hex("SDU Data", large_sdu, large_message.length());

  std::vector<RLC_Segment *> large_segments;
  segment_rlc_sdu(large_sdu, large_message.length(), 200, 60, large_segments,
                  false);

  // Create UMD PDUs for each segment
  std::cout << "\n[PDU CONSTRUCTION FOR ALL SEGMENTS]\n\n";
  std::vector<uint8_t *> pdus;
  std::vector<size_t> pdu_sizes;

  for (size_t i = 0; i < large_segments.size(); i++) {
    std::cout
        << "═════════════════════════════════════════════════════════════\n";
    std::cout << "Segment #" << (i + 1) << " PDU\n";
    std::cout
        << "═════════════════════════════════════════════════════════════\n";

    uint8_t *pdu = new uint8_t[100];
    size_t len;
    create_umd_pdu(large_segments[i], pdu, len);
    print_hex("UMD PDU", pdu, len);

    pdus.push_back(pdu);
    pdu_sizes.push_back(len);
    std::cout << "\n";
  }

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 3: Reassembly
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SCENARIO 3: SDU Reassembly from Segments                     "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n";

  uint8_t *reassembled = new uint8_t[large_message.length()];
  size_t reassembled_length = reassemble_rlc_sdu(large_segments, reassembled);

  std::cout << "[REASSEMBLY VERIFICATION]\n";
  std::cout << "  → Original Length: " << large_message.length() << " bytes\n";
  std::cout << "  → Reassembled Length: " << reassembled_length << " bytes\n";
  print_hex("Reassembled SDU", reassembled, reassembled_length);

  std::string reassembled_str(reinterpret_cast<char *>(reassembled),
                              reassembled_length);
  std::cout << "  → Reassembled Message: \"" << reassembled_str << "\"\n";

  bool match = (reassembled_length == large_message.length()) &&
               (memcmp(large_sdu, reassembled, large_message.length()) == 0);
  std::cout << "\n  Verification: " << (match ? "✓ SUCCESS" : "✗ FAILED")
            << "\n";
  std::cout << "  → Reassembled SDU matches original: "
            << (match ? "YES" : "NO") << "\n\n";

  // ═══════════════════════════════════════════════════════════════════════
  // SCENARIO 4: SI and SO Field Reference Table
  // ═══════════════════════════════════════════════════════════════════════

  std::cout << "\n";
  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SI FIELD REFERENCE (3GPP TS 38.322 Table 6.2.3.4-1)          "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::cout
      << "  ┌────────┬─────────────────────────────────────────┬──────────┐\n";
  std::cout
      << "  │ Value  │ Description                             │ SO Field │\n";
  std::cout
      << "  ├────────┼─────────────────────────────────────────┼──────────┤\n";
  std::cout
      << "  │  00b   │ Complete RLC SDU (no segmentation)      │    No    │\n";
  std::cout
      << "  │  01b   │ First segment of RLC SDU                │    No    │\n";
  std::cout
      << "  │  10b   │ Last segment of RLC SDU                 │   Yes    │\n";
  std::cout
      << "  │  11b   │ Middle segment of RLC SDU               │   Yes    │\n";
  std::cout
      << "  "
         "└────────┴─────────────────────────────────────────┴──────────┘\n\n";

  std::cout << "┌──────────────────────────────────────────────────────────────"
               "─────┐\n";
  std::cout << "│ SO FIELD SPECIFICATION (3GPP TS 38.322 Section 6.2.3.5)      "
               "    │\n";
  std::cout << "└──────────────────────────────────────────────────────────────"
               "─────┘\n\n";

  std::cout << "  Length: 16 bits\n";
  std::cout << "  Purpose: Indicates byte position within original RLC SDU\n";
  std::cout << "  Range: 0 - 65535 bytes\n";
  std::cout
      << "  Note: First byte of SDU is position 0 (numbering starts at zero)\n";
  std::cout << "  Special Value: 0xFFFF indicates \"to last byte of SDU\"\n\n";

  // Cleanup
  for (auto seg : large_segments)
    delete seg;
  for (auto pdu : pdus)
    delete[] pdu;
  delete[] large_sdu;
  delete[] reassembled;

  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n";
  std::cout << "  DEMONSTRATION COMPLETE\n";
  std::cout << "═══════════════════════════════════════════════════════════════"
               "════════\n\n";
}

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 7: MAIN FUNCTION
// ═══════════════════════════════════════════════════════════════════════════

int main() {
  demonstrate_segmentation();
  return 0;
}
